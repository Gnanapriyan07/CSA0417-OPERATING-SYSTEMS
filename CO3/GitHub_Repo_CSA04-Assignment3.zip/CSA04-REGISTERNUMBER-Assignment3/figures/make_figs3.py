import csv, re, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
plt.rcParams["font.family"]="serif"; plt.rcParams["font.serif"]=["Times New Roman","Liberation Serif","DejaVu Serif"]; plt.rcParams["font.size"]=10
W="/home/claude/w3/"
def box(ax,x,y,w,h,t,c="#deebf7",fs=9,ec="#1f4e79"):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.02",fc=c,ec=ec,lw=1.2)); ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=fs)
def arr(ax,a,b,t="",style="->"):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle=style,mutation_scale=12,lw=1.2,color="#333"))
    if t: ax.text((a[0]+b[0])/2,(a[1]+b[1])/2+.12,t,ha="center",fontsize=8)
def readcsv(p): return list(csv.DictReader(open(p)))
# --- Q1: sizes and start-up
fig,ax=plt.subplots(1,2,figsize=(7.2,3.1))
ax[0].bar(["static","dynamic"],[21757304/1e6,20987992/1e6],color=["#c55a11","#2e75b6"]); ax[0].set_ylabel("Executable size (MB)"); ax[0].set_title("Size of the program file")
for i,v in enumerate([21.757,20.988]): ax[0].text(i,v+.2,f"{v:.2f}",ha="center",fontsize=9)
lab=["static","dynamic\n(load time)","dlopen\n(needed)","dlopen\n(not needed)"]; v=[0.616,0.809,0.770,0.676]
ax[1].bar(lab,v,color=["#c55a11","#2e75b6","#548235","#7f7f7f"]); ax[1].set_ylabel("Median start-up (ms)"); ax[1].set_title("Start-up time (300 runs)")
for i,x in enumerate(v): ax[1].text(i,x+.01,f"{x:.3f}",ha="center",fontsize=9)
ax[1].tick_params(axis="x",labelsize=8); fig.tight_layout(); fig.savefig("fig_q1_link.png",dpi=200); plt.close()
# --- Q2: external fragmentation diagram
fig,ax=plt.subplots(figsize=(7.2,3.2)); ax.set_xlim(0,100); ax.set_ylim(0,10); ax.axis("off")
def row(y,blocks,title):
    ax.text(0,y+1.9,title,fontsize=9,weight="bold"); x=0
    for w,lab,c in blocks: ax.add_patch(Rectangle((x,y),w,1.6,fc=c,ec="k")); ax.text(x+w/2,y+.8,lab,ha="center",va="center",fontsize=8); x+=w
G="#f8cbad"; U="#bdd7ee"
row(7.2,[(10,"OS","#d9d9d9"),(20,"P1 (20)",U),(15,"P2 (15)",U),(15,"P3 (15)",U),(20,"P4 (20)",U),(20,"free 20",G)],"1. All memory in use by contiguous blocks (100 units)")
row(3.8,[(10,"OS","#d9d9d9"),(20,"P1",U),(15,"hole 15",G),(15,"P3",U),(20,"hole 20",G),(20,"P5 (20)",U)],"2. P2 and P4 finish; P5 loads into the last hole")
row(0.4,[(10,"OS","#d9d9d9"),(20,"P1",U),(15,"hole 15",G),(15,"P3",U),(20,"hole 20",G),(20,"P5",U)],"3. P6 needs 30 units: 35 free in total but largest hole is 20 -> cannot load")
fig.tight_layout(); fig.savefig("fig_q2_extfrag.png",dpi=200); plt.close()
# --- Q2: paging translation diagram
fig,ax=plt.subplots(figsize=(7.2,3.6)); ax.set_xlim(0,10); ax.set_ylim(0,6); ax.axis("off")
box(ax,0.1,3.7,2.2,1.6,"Logical address 1500\nPAGE_SIZE = 1024\np = 1500 / 1024 = 1\nd = 1500 mod 1024 = 476","#fff2cc",8.5,"#bf9000")
rows=[("0","5"),("1","2"),("2","-1 (fault)"),("3","7"),("4","0"),("5","-1 (fault)"),("6","3"),("7","-1 (fault)")]
ax.text(4.0,5.7,"Page table (page -> frame)",ha="center",fontsize=9,weight="bold")
for i,(p,f) in enumerate(rows):
    y=5.2-i*0.5; ax.add_patch(Rectangle((3.0,y),1.0,0.45,fc="#deebf7" if i!=1 else "#ffd966",ec="k")); ax.add_patch(Rectangle((4.0,y),1.8,0.45,fc="#deebf7" if i!=1 else "#ffd966",ec="k")); ax.text(3.5,y+.22,p,ha="center",va="center",fontsize=8.5); ax.text(4.9,y+.22,f,ha="center",va="center",fontsize=8.5)
arr(ax,(2.35,4.5),(3.0,4.55)); arr(ax,(5.8,4.55),(6.6,4.55))
box(ax,6.6,3.7,3.2,1.6,"Physical address\n= frame x PAGE_SIZE + d\n= 2 x 1024 + 476 = 2524","#e2f0d9",8.5,"#548235")
box(ax,0.1,0.0,9.7,1.1,"Page 2 -> frame -1: page fault (page not in memory)  |  page number >= 8: invalid address trap\nPaging removes external fragmentation: any free frame can hold any page, so no contiguous block is needed.","#ededed",8.5,"#7f7f7f")
fig.tight_layout(); fig.savefig("fig_q2_paging.png",dpi=200); plt.close()
# --- Q3: segmentation with paging (x86)
fig,ax=plt.subplots(figsize=(7.4,3.8)); ax.set_xlim(0,12); ax.set_ylim(0,6); ax.axis("off")
box(ax,0.1,4.2,2.3,1.3,"Logical address\nselector (16 bit)\n+ offset (32 bit)","#fff2cc",8,"#bf9000")
box(ax,3.0,4.2,2.4,1.3,"Segmentation unit\nGDT/LDT entry: base,\nlimit, rights; check\noffset <= limit","#deebf7",8)
box(ax,6.0,4.2,2.2,1.3,"Linear address\n= base + offset\n(32 bit)","#e2f0d9",8,"#548235")
arr(ax,(2.4,4.85),(3.0,4.85)); arr(ax,(5.4,4.85),(6.0,4.85))
box(ax,0.1,1.6,2.5,1.3,"Linear address split:\ndir (10) | table (10)\n| offset (12)","#ededed",8,"#7f7f7f")
box(ax,3.2,1.6,2.2,1.3,"Page directory\n(CR3 points to it)\nentry -> page table","#deebf7",8)
box(ax,6.0,1.6,2.2,1.3,"Page table\nentry -> frame\n(present, R/W, U/S)","#deebf7",8)
box(ax,9.0,1.6,2.6,1.3,"Physical address\n= frame base + offset\n(TLB caches result)","#e2f0d9",8,"#548235")
arr(ax,(7.1,4.2),(1.4,2.9)); arr(ax,(2.6,2.25),(3.2,2.25)); arr(ax,(5.4,2.25),(6.0,2.25)); arr(ax,(8.2,2.25),(9.0,2.25))
ax.text(6,0.6,"Offset > limit -> general-protection fault; page not present -> page fault; protection bits violated -> fault",ha="center",fontsize=8.5)
fig.tight_layout(); fig.savefig("fig_q3_segpaging.png",dpi=200); plt.close()
# --- Q4: page-fault steps
fig,ax=plt.subplots(figsize=(7.4,3.6)); ax.set_xlim(0,12); ax.set_ylim(0,6); ax.axis("off")
S=[(0.1,3.8,"1. Reference to a\npage marked invalid\nin the page table"),(3.1,3.8,"2. Trap to the OS\n(page-fault exception,\nsave registers)"),(6.1,3.8,"3. Check: valid but not\nin memory? (else\nterminate: bad address)"),(9.1,3.8,"4. Find a free frame\n(or evict a victim,\nwrite it if dirty)"),(9.1,0.9,"5. Schedule disk read\nof the page into the\nframe; run other process"),(6.1,0.9,"6. Disk interrupt:\nupdate page table\n(valid, frame number)"),(3.1,0.9,"7. Restart the\ninstruction that\nfaulted"),(0.1,0.9,"Process continues;\nthe fault is invisible\nto the program")]
for i,(x,y,t) in enumerate(S): box(ax,x,y,2.7,1.5,t,"#deebf7" if i<7 else "#e2f0d9",8)
for a,b in [((2.8,4.55),(3.1,4.55)),((5.8,4.55),(6.1,4.55)),((8.8,4.55),(9.1,4.55))]: arr(ax,a,b)
arr(ax,(10.45,3.8),(10.45,2.4)); arr(ax,(9.1,1.65),(8.8,1.65)); arr(ax,(6.1,1.65),(5.8,1.65)); arr(ax,(3.1,1.65),(2.8,1.65))
fig.tight_layout(); fig.savefig("fig_q4_pagefault.png",dpi=200); plt.close()
# --- Q4: runtime vs working set
rows=[]; 
for l in open(W+"Q4/memlimit_output.txt"):
    m=re.search(r"W=\s*(\d+) MB.*per access=\s*([\d.]+) ns.*major=(\d+)",l)
    if m: rows.append((int(m[1]),float(m[2]),int(m[3])))
fig,ax=plt.subplots(figsize=(6.4,3.4)); ax.plot([r[0] for r in rows],[r[1] for r in rows],"o-",color="#1f4e79"); ax.set_yscale("log"); ax.axvline(128,color="#c55a11",ls="--"); ax.text(131,8,"RAM limit\n128 MB",color="#c55a11",fontsize=9)
ax.set_xlabel("Working set size (MB)"); ax.set_ylabel("Mean time per random access (ns, log)"); ax.set_title("Measured slow-down when memory use exceeds RAM"); ax.grid(True,which="both",alpha=.3)
fig.tight_layout(); fig.savefig("fig_q4_runtime.png",dpi=200); plt.close()
# --- Q4/Q5: faults vs frames, textbook string; Belady
def curve(fn,title,out,cols=("FIFO","LRU","Optimal","Clock"),xl="Number of frames",yl="Page faults",mk=("o-","s-","^-","d--")):
    d=readcsv(fn); fig,ax=plt.subplots(figsize=(6,3.4))
    for c,m in zip(cols,mk): ax.plot([int(r["frames"]) for r in d],[int(r[c]) for r in d],m,label=c)
    ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(title); ax.legend(); ax.grid(alpha=.3); fig.tight_layout(); fig.savefig(out,dpi=200); plt.close()
curve(W+"Q5/curve_ref20.csv","Faults vs frames: textbook string (20 references)","fig_q4_faults_frames.png")
curve(W+"Q5/curve_belady.csv","Belady string (12 references): FIFO rises from 3 to 4 frames","fig_q5_belady.png")
fig,ax=plt.subplots(1,2,figsize=(7.6,3.4),sharey=True)
for a,(fn,t) in zip(ax,[("curve_locality.csv","Strong locality (10,000 refs)"),("curve_random.csv","Random access (10,000 refs)")]):
    d=readcsv(W+"Q5/"+fn)
    for c,m in zip(("FIFO","LRU","Optimal","Clock"),("o-","s-","^-","d--")): a.plot([int(r["frames"]) for r in d],[int(r[c]) for r in d],m,label=c,ms=4)
    a.set_title(t,fontsize=10); a.set_xlabel("Number of frames"); a.grid(alpha=.3)
ax[0].set_ylabel("Page faults (mean of 5 strings)"); ax[0].legend(fontsize=8); fig.tight_layout(); fig.savefig("fig_q5_curves.png",dpi=200); plt.close()
# --- Q7 latency
mx={"unlocked":[],"locked":[]}; p999={"unlocked":[],"locked":[]}
for l in open(W+"Q7/rt_test_output.txt"):
    m=re.match(r"(unlocked|locked)\s.*p99\.9=\s*([\d.]+) us\s+MAX=\s*([\d.]+) us",l)
    if m: p999[m[1]].append(float(m[2])); mx[m[1]].append(float(m[3]))
fig,ax=plt.subplots(figsize=(6.2,3.3)); import numpy as np; x=np.arange(3)
ax.bar(x-0.2,mx["unlocked"],0.4,label="not locked",color="#c55a11"); ax.bar(x+0.2,mx["locked"],0.4,label="mlockall()",color="#2e75b6"); ax.set_yscale("log")
for i,(a,b) in enumerate(zip(mx["unlocked"],mx["locked"])): ax.text(i-0.2,a*1.1,f"{a:.0f}",ha="center",fontsize=8); ax.text(i+0.2,b*1.1,f"{b:.0f}",ha="center",fontsize=8)
ax.axhline(200,color="k",ls=":"); ax.text(2.45,215,"200 us budget",fontsize=8,ha="right"); ax.set_xticks(x); ax.set_xticklabels(["run 1","run 2","run 3"]); ax.set_ylabel("Worst iteration time (us, log)"); ax.set_title("Worst-case delay of the control loop (5,000 iterations)"); ax.legend(); fig.tight_layout(); fig.savefig("fig_q7_latency.png",dpi=200); plt.close()
print("figs ok", rows[:2], mx, p999)
