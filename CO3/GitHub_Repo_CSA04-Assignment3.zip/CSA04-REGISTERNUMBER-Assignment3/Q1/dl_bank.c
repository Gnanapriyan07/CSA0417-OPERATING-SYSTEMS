/* Same application, but the encryption library is loaded with dlopen() only when needed.
   Usage: dl_bank [-n] [-q]   -n = no encryption needed (library never loaded) */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include "bankenc.h"
static const unsigned char app_blob[20u * 1024 * 1024] = {1, 2, 3};
int main(int argc, char **argv)
{
    int need = 1, quiet = 0;
    for (int i = 1; i < argc; i++) { if (!strcmp(argv[i], "-n")) need = 0; if (!strcmp(argv[i], "-q")) quiet = 1; }
    unsigned char msg[] = "ACCOUNT=1234 AMOUNT=0000100 AAAAAAAA";
    if (need) {
        void *h = dlopen("./libbankenc.so", RTLD_NOW);
        if (!h) { fprintf(stderr, "ERROR: cannot load encryption library: %s\nFalling back: refusing to send data in clear text.\n", dlerror()); return 2; }
        void (*enc)(unsigned char *, size_t, unsigned char) = (void (*)(unsigned char *, size_t, unsigned char))dlsym(h, "encrypt_buf");
        const char *(*ver)(void) = (const char *(*)(void))dlsym(h, "enc_version");
        if (!enc || !ver) { fprintf(stderr, "ERROR: symbol missing: %s\n", dlerror()); dlclose(h); return 3; }
        enc(msg, sizeof msg - 1, 0x5A);
        if (!quiet) { printf("dlopen OK, library %s at ", ver()); Dl_info di; dladdr((void *)enc, &di); printf("%p (%s)\n", di.dli_fbase, di.dli_fname); }
        dlclose(h);
    } else if (!quiet) printf("encryption not needed: library not loaded (app_blob[0]=%d)\n", app_blob[0]);
    return 0;
}
