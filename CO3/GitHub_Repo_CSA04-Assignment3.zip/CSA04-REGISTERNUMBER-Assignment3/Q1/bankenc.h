#ifndef BANKENC_H
#define BANKENC_H
#include <stddef.h>
const char *enc_version(void);
void encrypt_buf(unsigned char *buf, size_t n, unsigned char key);
#endif
