/* Encryption library, version 1 (contains the bug that the "security fix" removes:
   key is applied without rotating, so identical plaintext bytes give identical output). */
#include "bankenc.h"
const char *enc_version(void) { return "bankenc 1.0 (weak: plain XOR)"; }
void encrypt_buf(unsigned char *buf, size_t n, unsigned char key)
{
    for (size_t i = 0; i < n; i++) buf[i] ^= key;
}
