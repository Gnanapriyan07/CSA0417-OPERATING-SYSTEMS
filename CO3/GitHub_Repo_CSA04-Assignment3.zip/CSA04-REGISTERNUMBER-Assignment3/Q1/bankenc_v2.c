/* Version 2 = the security fix: key is mixed with the position, so equal bytes differ. */
#include "bankenc.h"
const char *enc_version(void) { return "bankenc 2.0 (fixed: position-dependent key)"; }
void encrypt_buf(unsigned char *buf, size_t n, unsigned char key)
{
    for (size_t i = 0; i < n; i++) buf[i] ^= (unsigned char)(key + 31 * i);
}
