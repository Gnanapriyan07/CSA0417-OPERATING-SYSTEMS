/* Bank branch application. app_blob stands for the large application code/data
   (20 MB here; 200 MB in the scenario). Usage: bank [-q|-s]   (-q = quiet, for timing; -s = quiet and sleep 6 s) */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "bankenc.h"
static const unsigned char app_blob[20u * 1024 * 1024] = {1, 2, 3};
static void show_maps(void)
{
    FILE *f = fopen("/proc/self/maps", "r"); char line[512];
    while (f && fgets(line, sizeof line, f))
        if (strstr(line, "bank") || strstr(line, "libc.so") || strstr(line, "ld-linux") || strstr(line, "[stack]") || strstr(line, "[heap]"))
            fputs(line, stdout);
    if (f) fclose(f);
}
int main(int argc, char **argv)
{
    int quiet = argc > 1 && (!strcmp(argv[1], "-q") || !strcmp(argv[1], "-s"));
    int sleepy = argc > 1 && !strcmp(argv[1], "-s");   /* -s: stay alive 6 s so /proc can be inspected */
    unsigned char msg[] = "ACCOUNT=1234 AMOUNT=0000100 AAAAAAAA";
    encrypt_buf(msg, sizeof msg - 1, 0x5A);
    if (!quiet) {
        printf("library: %s\napp_blob[0..2]=%d,%d,%d\nciphertext hex: ", enc_version(), app_blob[0], app_blob[1], app_blob[2]);
        for (size_t i = 0; i < sizeof msg - 1; i++) printf("%02x", msg[i]);
        printf("\n--- /proc/self/maps (selected) ---\n"); show_maps();
    }
    if (sleepy) sleep(6);
    return 0;
}
