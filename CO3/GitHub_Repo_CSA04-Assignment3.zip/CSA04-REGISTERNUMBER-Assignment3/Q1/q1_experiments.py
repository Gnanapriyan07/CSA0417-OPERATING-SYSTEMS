#!/usr/bin/env python3
"""Q1 experiments: start-up time, memory, library replacement, page sharing, missing library."""
import subprocess, time, statistics as st, os, shutil, re, sys
def startup(cmd, n=300):
    ts=[]
    for _ in range(n):
        t=time.perf_counter(); subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); ts.append((time.perf_counter()-t)*1000)
    return st.median(ts), min(ts), st.mean(ts)
def maxrss(cmd):
    r=subprocess.run(["/usr/bin/time","-f","%M"]+cmd,capture_output=True,text=True); return int(r.stderr.strip().splitlines()[-1])
print("== A. Start-up time (ms, 300 runs: median / min / mean)")
cases=[("static",["./bank_static","-q"]),("dynamic (load-time)",["./bank_dynamic","-q"]),("dlopen, library needed",["./dl_bank","-q"]),("dlopen, library NOT needed",["./dl_bank","-n","-q"])]
for name,c in cases:
    m,mn,mean=startup(c); print(f"{name:30s} {m:7.3f} {mn:7.3f} {mean:7.3f}")
print("== B. Peak resident memory (KB, GNU time %M, median of 20)")
for name,c in cases:
    print(f"{name:30s} {st.median(maxrss(c) for _ in range(20))}")
print("== C. Replace the shared library without recompiling")
print("before:", subprocess.run(["./bank_dynamic"],capture_output=True,text=True).stdout.splitlines()[0], "| static:", subprocess.run(["./bank_static"],capture_output=True,text=True).stdout.splitlines()[0])
shutil.copy("libbankenc_v2.so","libbankenc.so")
out=subprocess.run(["./bank_dynamic"],capture_output=True,text=True).stdout.splitlines()
print("after copying libbankenc_v2.so over libbankenc.so (program NOT recompiled):"); print(out[0]); print(out[2])
print("static program unchanged:", subprocess.run(["./bank_static"],capture_output=True,text=True).stdout.splitlines()[0])
print("bytes to ship: shared lib =",os.path.getsize("libbankenc_v2.so"),"; static executable =",os.path.getsize("bank_static"))
shutil.copy("libbankenc_v1.so","libbankenc.so")
print("== D. Two copies: which pages are shared (PFN comparison via /proc/PID/pagemap, run as root)")
def regions(pid):
    r=[]
    for l in open(f"/proc/{pid}/maps"):
        p=l.split(None,5)
        if len(p)==6 and ("libc.so" in p[5] or "libbankenc" in p[5] or "bank_dynamic" in p[5]):
            a,b=[int(x,16) for x in p[0].split("-")]; r.append((a,b,p[1],p[5].strip()))
    return r
def pfns(pid,a,b):
    out={}
    with open(f"/proc/{pid}/pagemap","rb") as f:
        for va in range(a,b,4096):
            f.seek(va//4096*8); e=int.from_bytes(f.read(8),"little")
            if e>>63&1: out[va]=e&((1<<55)-1)
    return out
for exe in ("./bank_dynamic","./bank_static"):
    p1=subprocess.Popen([exe,"-s"]); p2=subprocess.Popen([exe,"-s"]); time.sleep(1.5)
    print("--",exe,"pids",p1.pid,p2.pid)
    if exe.endswith("dynamic"):
        # r1 and r2 regions line up by file+permission+order (ASLR changes addresses, not content)
        R1,R2=regions(p1.pid),regions(p2.pid)
        agg={}
        for (a1,b1,pm,fn),(a2,b2,_,_) in zip(R1,R2):
            m1,m2=pfns(p1.pid,a1,b1),pfns(p2.pid,a2,b2)
            k=(os.path.basename(fn),pm); shared=sum(1 for o in range(0,b1-a1,4096) if a1+o in m1 and a2+o in m2 and m1[a1+o]==m2[a2+o]); tot=sum(1 for o in range(0,b1-a1,4096) if a1+o in m1)
            s=agg.get(k,[0,0]); agg[k]=[s[0]+tot,s[1]+shared]
        for k,(tot,sh) in agg.items(): print(f"   {k[0]:22s} {k[1]}  resident pages in copy 1: {tot:4d}   same physical frame in copy 2: {sh:4d}")
    for pid in (p1.pid,):
        s=open(f"/proc/{pid}/smaps_rollup").read()
        print("   smaps_rollup copy1:", " ".join(re.findall(r"^(Rss|Pss|Shared_Clean|Shared_Dirty|Private_Clean|Private_Dirty):\s+(\d+) kB",s,re.M) and [f"{k}={v}kB" for k,v in re.findall(r"^(Rss|Pss|Shared_Clean|Private_Clean|Private_Dirty):\s+(\d+) kB",s,re.M)]))
    p1.wait(); p2.wait()
print("== E. Shared library missing")
os.rename("libbankenc.so","libbankenc.so.moved")
r=subprocess.run(["./bank_dynamic"],capture_output=True,text=True); print("bank_dynamic exit code",r.returncode,"| stderr:",r.stderr.strip())
r=subprocess.run(["./dl_bank"],capture_output=True,text=True); print("dl_bank (dlopen) exit code",r.returncode,"| stderr:",r.stderr.strip().replace("\n"," / "))
r=subprocess.run(["./bank_static"],capture_output=True,text=True); print("bank_static exit code",r.returncode,"(not affected)")
os.rename("libbankenc.so.moved","libbankenc.so")
