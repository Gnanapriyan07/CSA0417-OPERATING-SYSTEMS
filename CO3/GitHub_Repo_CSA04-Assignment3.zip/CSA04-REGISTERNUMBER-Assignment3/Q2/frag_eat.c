/* Q2 experiments: (1) internal fragmentation of 100 random processes for 1 KB, 4 KB, 2 MB pages;
   (2) effective access time with/without TLB; (3) page-table sizes.  Seed is fixed for repeatability. */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(void)
{
    srand(2024);
    enum { N = 100 };
    unsigned long long size[N];
    for (int i = 0; i < N; i++) size[i] = 10240ull + ((unsigned long long)rand() * 32768ull + rand()) % (10ull * 1048576 - 10240);  /* 10 KB .. 10 MB */
    unsigned long long ps[3] = {1024, 4096, 2097152}; const char *nm[3] = {"1 KB", "4 KB", "2 MB"};
    unsigned long long total = 0; for (int i = 0; i < N; i++) total += size[i];
    printf("100 processes, sizes 10 KB..10 MB (seed 2024): total %.2f MB, mean %.2f KB\n", total / 1048576.0, total / 1024.0 / N);
    printf("%-6s %12s %14s %14s %12s %14s\n", "page", "pages used", "internal (KB)", "mean/proc(KB)", "waste %", "PT entries");
    for (int k = 0; k < 3; k++) {
        unsigned long long pages = 0, frag = 0;
        for (int i = 0; i < N; i++) { unsigned long long np = (size[i] + ps[k] - 1) / ps[k]; pages += np; frag += np * ps[k] - size[i]; }
        printf("%-6s %12llu %14.1f %14.2f %11.3f%% %14llu\n", nm[k], pages, frag / 1024.0, frag / 1024.0 / N, 100.0 * frag / (frag + total), pages);
    }
    puts("\nEffective access time (memory = 100 ns, TLB look-up = 10 ns):");
    double m = 100, t = 10, hit[3] = {0.80, 0.95, 0.99};
    printf("without TLB: 1-level table = %.0f ns ; 2-level = %.0f ns ; 4-level = %.0f ns\n", 2 * m, 3 * m, 5 * m);
    for (int l = 1; l <= 4; l += (l == 1 ? 1 : 2)) {   /* levels 1?,2,4 */
        for (int h = 0; h < 3; h++) {
            double eat = hit[h] * (t + m) + (1 - hit[h]) * (t + (l + 1) * m);
            printf("TLB hit %2.0f%%, %d-level table: EAT = %7.2f ns  (%.1f%% over 100 ns)\n", hit[h] * 100, l, eat, (eat - m));
        }
    }
    puts("\nPage-table size with 4 KB pages (4-byte entries for 32-bit, 8-byte entries for 48-bit):");
    unsigned long long e32 = 1ull << 20, e48 = 1ull << 36;
    printf("32-bit: 2^32/2^12 = %llu entries x 4 B = %.0f MB per process\n", e32, e32 * 4 / 1048576.0);
    printf("48-bit: 2^48/2^12 = %llu entries x 8 B = %.0f GB per process (single level)\n", e48, e48 * 8 / 1073741824.0);
    return 0;
}
