/* Allocate N MB, touch one byte per page sequentially, report page faults (getrusage). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
int main(int argc, char **argv)
{
    size_t mb = argc > 1 ? (size_t)atol(argv[1]) : 64, n = mb << 20;
    char *p = malloc(n); if (!p) return 1;
    for (size_t i = 0; i < n; i += 4096) p[i] = 1;
    struct rusage r; getrusage(RUSAGE_SELF, &r);
    printf("touched %zu MB = %zu pages; minor faults %ld, major faults %ld\n", mb, n / 4096, r.ru_minflt, r.ru_majflt);
    return 0;
}
