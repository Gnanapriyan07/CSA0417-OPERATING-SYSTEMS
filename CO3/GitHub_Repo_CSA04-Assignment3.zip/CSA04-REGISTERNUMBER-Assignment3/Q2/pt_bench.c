/* Alternative concept benchmark: translate random virtual pages with
   (a) a 4-level radix page table (4 dependent memory reads)  and
   (b) an inverted page table with a hash index (one hash + short chain).
   A 1 GB physical memory (262,144 frames of 4 KB) is modelled; a process maps 200,000 pages
   spread over a 48-bit address space (so the radix tree is sparse). */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
typedef struct node { void *e[512]; } node;
static node *newnode(size_t *cnt){ (*cnt)++; return calloc(1, sizeof(node)); }
#define NF 262144u
#define HB 524288u            /* hash buckets (2 per frame) */
typedef struct { uint32_t pid; uint64_t vpn; int32_t next; } ipt_e;
static ipt_e ipt[NF]; static int32_t bucket[HB];
static uint32_t hash(uint32_t pid, uint64_t vpn){ uint64_t x = vpn * 0x9E3779B97F4A7C15ull ^ pid; return (uint32_t)(x >> 40) & (HB - 1); }
int main(void)
{
    srand(7); enum { M = 200000 };
    static uint64_t vpn[M]; size_t nodes = 0; node *root = newnode(&nodes);
    for (uint32_t i = 0; i < HB; i++) bucket[i] = -1;
    for (int i = 0; i < M; i++) {
        uint64_t v = (((uint64_t)rand() << 31) ^ (uint64_t)rand()) & ((1ull << 36) - 1); vpn[i] = v;   /* scattered: worst case for a radix tree */
        node *n = root;
        for (int lv = 3; lv >= 1; lv--) { int ix = (v >> (9 * lv)) & 511; if (!n->e[ix]) n->e[ix] = newnode(&nodes); n = n->e[ix]; }
        n->e[v & 511] = (void *)(uintptr_t)(i % NF + 1);                    /* leaf entry holds frame+1 */
        uint32_t f = i % NF;                                                  /* inverted table: entry f describes frame f */
        ipt[f].pid = 1; ipt[f].vpn = v; uint32_t h = hash(1, v); ipt[f].next = bucket[h]; bucket[h] = f;
    }
    const int L = 5000000; volatile uint64_t sink = 0; double t = now();
    for (int k = 0; k < L; k++) { uint64_t v = vpn[(k * 2654435761u) % M]; node *n = root;
        for (int lv = 3; lv >= 1; lv--) { n = n->e[(v >> (9 * lv)) & 511]; }
        sink += (uintptr_t)n->e[v & 511]; }
    double a = (now() - t) / L * 1e9;
    t = now(); long chain = 0;
    for (int k = 0; k < L; k++) { uint64_t v = vpn[(k * 2654435761u) % M]; int32_t f = bucket[hash(1, v)];
        while (f >= 0 && !(ipt[f].vpn == v && ipt[f].pid == 1)) { f = ipt[f].next; chain++; } sink += f; }
    double b = (now() - t) / L * 1e9;
    printf("mapped pages: %d\n", M);
    printf("4-level radix: %.1f ns per translation, table memory = %zu nodes x 4096 B = %.1f MB (grows with this process's address-space use)\n", a, nodes, nodes * 4096.0 / 1048576);
    printf("inverted+hash: %.1f ns per translation, avg extra chain steps = %.2f, table memory = %.1f MB (262,144 frames x 16 B + hash index), independent of number/size of processes\n", b, (double)chain / L, (NF * sizeof(ipt_e) + HB * 4.0) / 1048576);
    return 0;
}
