#include <stdio.h>

#define PAGE_SIZE 1024
#define PAGES 8

/* Page table of a process: frame number, or -1 if the page is not in memory. */
int page_table[PAGES] = {5, 2, -1, 7, 0, -1, 3, -1};

int main(void)
{
    unsigned logical[] = {0, 1023, 1024, 8191, 8192, 6143, 6144, 2047, 2048, 4294967295u};
    for (int i = 0; i < 10; i++) {
        unsigned a = logical[i];
        // TODO 1 (completed): split a into page number p and offset d
        unsigned p = a / PAGE_SIZE, d = a % PAGE_SIZE;
        printf("%u -> page %u offset %u : ", a, p, d);
        if (p >= PAGES) printf("invalid address\n");
        else if (page_table[p] == -1) printf("page fault\n");
        else printf("physical %u\n", (unsigned)page_table[p] * PAGE_SIZE + d);
    }
    return 0;
}
