#!/bin/bash
# Run the control loop with and without mlockall, with a memory hog competing in a 96 MB cgroup.
CG=/sys/fs/cgroup/memory/q7; mkdir -p $CG; echo $((96*1024*1024)) > $CG/memory.limit_in_bytes
FILE=/tmp/data512.bin; ITER=${1:-5000}
echo "cgroup limit 96 MB; control table 48 MB; hog touches random pages of a 384 MB file; $ITER iterations of a 1 ms loop"
for round in 1 2 3; do
  for mode in unlocked locked; do
    sync; echo 3 > /proc/sys/vm/drop_caches
    bash -c "echo \$\$ > $CG/cgroup.procs; exec ./hog $FILE" & HP=$!; sleep 1
    bash -c "echo \$\$ > $CG/cgroup.procs; exec ./rt_loop $mode $ITER $FILE"
    kill $HP; wait $HP 2>/dev/null
  done
done
