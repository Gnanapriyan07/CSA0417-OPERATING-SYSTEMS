/* Memory hog: stands for other tasks (ML + logging) competing for RAM. Allocates 24 MB anonymous memory
   and keeps touching random pages of a 384 MB file mapping, which forces the kernel to reclaim page cache. */
#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
int main(int argc, char **argv)
{
    (void)argc; size_t W = 384u << 20, pages = W / 4096; int fd = open(argv[1], O_RDONLY); char *anon = malloc(24u << 20); memset(anon, 1, 24u << 20);
    volatile unsigned char *p = mmap(NULL, W, PROT_READ, MAP_PRIVATE, fd, 0); madvise((void *)p, W, MADV_RANDOM);
    unsigned long long x = 123456789ull; unsigned long s = 0;
    for (;;) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; s += p[(x % pages) * 4096]; if (s == 0xdeadbeef) puts("x"); }
}
