/* Q7: time-critical control loop. The control task reads 4 random pages of a 48 MB lookup table
   (file-backed mapping, standing for calibration/model data) every 1 ms and records how long each
   iteration takes.  Mode "unlocked": ordinary demand-paged memory.  Mode "locked": mlockall().
   Usage: rt_loop <locked|unlocked> <iterations> <file>                                          */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/resource.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1e6+t.tv_nsec/1e3; }   /* microseconds */
static int cmp(const void *a, const void *b){ double x = *(const double *)a, y = *(const double *)b; return (x > y) - (x < y); }
int main(int argc, char **argv)
{
    if (argc < 4) return 2;
    int locked = !strcmp(argv[1], "locked"); int iters = atoi(argv[2]); const size_t W = 48u << 20, pages = W / 4096;
    int fd = open(argv[3], O_RDONLY); if (fd < 0) { perror("open"); return 1; }
    volatile unsigned char *t = mmap(NULL, W, PROT_READ, MAP_PRIVATE, fd, 0); if (t == MAP_FAILED) { perror("mmap"); return 1; }
    madvise((void *)t, W, MADV_RANDOM);
    if (locked) { if (mlockall(MCL_CURRENT | MCL_FUTURE)) { perror("mlockall"); return 1; } }     /* pre-faults and pins every page */
    else { for (size_t i = 0; i < pages; i++) (void)t[i * 4096]; }                                  /* just warm the pages once */
    double *lat = malloc(iters * sizeof *lat); unsigned long long x = 88172645463325252ull; unsigned long s = 0;
    struct rusage a, b; getrusage(RUSAGE_SELF, &a);
    struct timespec next; clock_gettime(CLOCK_MONOTONIC, &next);
    for (int i = 0; i < iters; i++) {
        next.tv_nsec += 1000000; if (next.tv_nsec >= 1000000000) { next.tv_nsec -= 1000000000; next.tv_sec++; }
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL);                                // 1 ms period
        double t0 = now();
        for (int k = 0; k < 4; k++) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; s += t[(x % pages) * 4096]; }
        lat[i] = now() - t0;
    }
    getrusage(RUSAGE_SELF, &b);
    double mean = 0, mx = 0; int miss = 0; for (int i = 0; i < iters; i++) { mean += lat[i]; if (lat[i] > mx) mx = lat[i]; if (lat[i] > 200) miss++; } mean /= iters;
    qsort(lat, iters, sizeof *lat, cmp);
    printf("%-8s iters=%d  mean=%7.2f us  p99=%8.2f us  p99.9=%9.2f us  MAX=%10.2f us  major faults=%ld minor=%ld  deadline(200us) misses=%d (s=%lu)\n",
           argv[1], iters, mean, lat[(int)(iters * 0.99)], lat[(int)(iters * 0.999)], mx, b.ru_majflt - a.ru_majflt, b.ru_minflt - a.ru_minflt,
           miss, s & 1);
    return 0;
}
