/* Q7 Stage 3: page-replacement simulation of the 2 GB edge device (no swap).  1 frame = 1 MB.
   Frames: 2048 total, 256 reserved for kernel/OS -> 1792 for the tasks.
   Pages are either PINNED (anonymous memory: cannot be evicted because there is no swap, or locked with mlock)
   or EVICTABLE (file-backed: code, model weights, log cache; can be dropped and re-read from flash).
   Tasks (scenario A): control(RT) 64 MB | ML 1536 MB = 436 anon + 1100 weights (file-backed) | logging 128 MB = 32 anon + 96 file.
   Scenario B adds task 4: 500 MB = 100 anon + 400 file-backed.
   Reference behaviour per 1 ms tick: RT touches 8 random pages of its 64; ML reads the next 10 weight pages of a cyclic sweep;
   logger appends the next page of its 96-page file cache; task 4 touches 5 random of its 400.
   Replacement policy for evictable pages: LRU.  RT pages are pinned (mlock) or evictable (not locked).
   Usage: memsim <A|B> <pin_rt 0|1>                                                                         */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TOTAL 2048
#define OS 256
#define TICKS 100000
enum { RT, ML, LOG, T4, NT };
static const char *nm[NT] = {"control(RT)", "ML", "logging", "task4"};
static int firstpage[NT], npages[NT];
static int resident[4096], lastuse[4096], owner[4096], pinned[4096];
static long faults[NT], refs[NT];
static int cap;
static void ref_page(int pg, long t)
{
    int o = owner[pg]; refs[o]++;
    if (resident[pg]) { lastuse[pg] = (int)t; return; }
    faults[o]++;
    int evictable_res = 0, victim = -1; long oldest = 1L << 60;
    for (int i = 0; i < 4096; i++) if (resident[i] && !pinned[i]) { evictable_res++; if (lastuse[i] < oldest) { oldest = lastuse[i]; victim = i; } }
    if (evictable_res >= cap && victim >= 0) resident[victim] = 0;
    resident[pg] = 1; lastuse[pg] = (int)t;
}
int main(int argc, char **argv)
{
    int scen = argc > 1 && argv[1][0] == 'B', pin_rt = argc > 2 && argv[2][0] == '1';
    int need[NT] = {64, 1536, 128, scen ? 500 : 0}, anon[NT] = {0, 436, 32, scen ? 100 : 0};
    int p = 0; for (int k = 0; k < NT; k++) { firstpage[k] = p; npages[k] = need[k]; p += need[k]; }
    int pin_total = 0;
    for (int k = 0; k < NT; k++) for (int i = 0; i < npages[k]; i++) {
        int pg = firstpage[k] + i; owner[pg] = k;
        pinned[pg] = (k == RT) ? pin_rt : (i < anon[k]);          /* first 'anon' pages of a task are anonymous = pinned (no swap) */
        if (pinned[pg]) { pin_total++; resident[pg] = 1; }
    }
    cap = TOTAL - OS - pin_total;
    printf("Scenario %c, RT %s: demand %d MB, anonymous/pinned %d MB, frames for evictable pages = %d (evictable demand %d MB)\n", scen ? 'B' : 'A', pin_rt ? "mlock'ed" : "NOT locked", p, pin_total, cap, p - pin_total);
    if (cap < 0) { puts("OUT OF MEMORY: pinned memory exceeds RAM (no swap to fall back on)"); return 1; }
    srand(11); int mlpos = 0, logpos = 0;
    for (long t = 1; t <= TICKS; t++) {
        for (int k = 0; k < 8; k++) ref_page(firstpage[RT] + rand() % npages[RT], t);
        for (int k = 0; k < 10; k++) { ref_page(firstpage[ML] + anon[ML] + mlpos, t); mlpos = (mlpos + 1) % (npages[ML] - anon[ML]); }
        ref_page(firstpage[LOG] + anon[LOG] + logpos, t); logpos = (logpos + 1) % (npages[LOG] - anon[LOG]);
        if (scen) for (int k = 0; k < 5; k++) ref_page(firstpage[T4] + anon[T4] + rand() % (npages[T4] - anon[T4]), t);
    }
    printf("%-12s %10s %10s %10s\n", "task", "references", "faults", "fault rate");
    for (int k = 0; k < NT; k++) if (need[k]) printf("%-12s %10ld %10ld %9.4f%%\n", nm[k], refs[k], faults[k], 100.0 * faults[k] / refs[k]);
    return 0;
}
