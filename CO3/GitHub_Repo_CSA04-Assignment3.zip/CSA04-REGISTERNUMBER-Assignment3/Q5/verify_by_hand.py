#!/usr/bin/env python3
"""Independent re-implementation (different code, different data structures) used to verify the C simulator."""
def fifo(r,n):
    q=[];f=0
    for x in r:
        if x not in q:
            f+=1
            if len(q)==n: q.pop(0)
            q.append(x)
    return f
def lru(r,n):
    q=[];f=0                      # most recent at the end
    for x in r:
        if x in q: q.remove(x)
        else:
            f+=1
            if len(q)==n: q.pop(0)
        q.append(x)
    return f
def opt(r,n):
    m=[];f=0
    for i,x in enumerate(r):
        if x in m: continue
        f+=1
        if len(m)==n:
            def nxt(p):
                try: return r.index(p,i+1)
                except ValueError: return 10**9
            m.remove(max(m,key=nxt))
        m.append(x)
    return f
ref=[7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1]; bel=[1,2,3,4,1,2,5,1,2,3,4,5]
for n in (3,4): print(f"{n} frames: FIFO {fifo(ref,n)}, LRU {lru(ref,n)}, Optimal {opt(ref,n)}")
print("Belady string, FIFO: 3 frames",fifo(bel,3),"faults, 4 frames",fifo(bel,4),"faults; LRU:",lru(bel,3),lru(bel,4))
import csv
c=list(csv.DictReader(open('curve_ref20.csv')))
ok=all(int(r['FIFO'])==fifo(ref,int(r['frames'])) and int(r['LRU'])==lru(ref,int(r['frames'])) and int(r['Optimal'])==opt(ref,int(r['frames'])) for r in c)
print("python == C simulator for frames 1..7 (FIFO, LRU, Optimal):",ok)
