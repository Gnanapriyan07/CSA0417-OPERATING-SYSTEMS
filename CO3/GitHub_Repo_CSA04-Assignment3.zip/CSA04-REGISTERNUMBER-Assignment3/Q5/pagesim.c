/* Extended page-replacement simulator: FIFO, LRU, Optimal, Clock (second chance).
   Modes:
     pagesim trace            -> step-by-step trace for the hand-check string (3 frames)
     pagesim curve <kind>     -> faults for 3..10 frames, kind = locality | random  (CSV)
     pagesim time             -> run time of each algorithm for 100,000 references
     pagesim belady           -> FIFO/LRU/OPT/Clock for frames 1..7 on the Belady string
     pagesim ref              -> frames 1..7 on the textbook 20-reference string (CSV)           */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MAXF 16
#define PAGES 64
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
static int find(const int f[], int n, int page){ for (int i = 0; i < n; i++) if (f[i] == page) return i; return -1; }
static int fifo(const int *ref, int len, int frames, int trace)
{
    int f[MAXF], used = 0, next = 0, faults = 0;
    for (int i = 0; i < len; i++) {
        int hit = find(f, used, ref[i]) >= 0; char note[32] = "";
        if (!hit) { faults++; if (used < frames) f[used++] = ref[i]; else { snprintf(note, sizeof note, "evict %d", f[next]); f[next] = ref[i]; next = (next + 1) % frames; } }
        if (trace) { printf("%2d: ref %d  [", i + 1, ref[i]); for (int k = 0; k < frames; k++) k < used ? printf(" %d", f[k]) : printf(" -"); printf(" ]  %s %s\n", hit ? "hit" : "FAULT", note); }
    }
    return faults;
}
static int lru(const int *ref, int len, int frames, int trace)
{
    int f[MAXF], last[MAXF], used = 0, faults = 0;
    for (int i = 0; i < len; i++) {
        int k = find(f, used, ref[i]); char note[32] = ""; int hit = k >= 0;
        if (hit) last[k] = i;
        else { faults++; if (used < frames) { f[used] = ref[i]; last[used++] = i; } else { int v = 0; for (int j = 1; j < frames; j++) if (last[j] < last[v]) v = j; snprintf(note, sizeof note, "evict %d", f[v]); f[v] = ref[i]; last[v] = i; } }
        if (trace) { printf("%2d: ref %d  [", i + 1, ref[i]); for (int q = 0; q < frames; q++) q < used ? printf(" %d", f[q]) : printf(" -"); printf(" ]  %s %s\n", hit ? "hit" : "FAULT", note); }
    }
    return faults;
}
static int optimal(const int *ref, int len, int frames, int trace)
{
    int f[MAXF], used = 0, faults = 0;
    for (int i = 0; i < len; i++) {
        int hit = find(f, used, ref[i]) >= 0; char note[32] = "";
        if (!hit) { faults++; if (used < frames) f[used++] = ref[i]; else {
            int v = 0, far = -1; for (int j = 0; j < frames; j++) { int nx = len; for (int t = i + 1; t < len; t++) if (ref[t] == f[j]) { nx = t; break; } if (nx > far) { far = nx; v = j; } }
            snprintf(note, sizeof note, "evict %d", f[v]); f[v] = ref[i]; } }
        if (trace) { printf("%2d: ref %d  [", i + 1, ref[i]); for (int q = 0; q < frames; q++) q < used ? printf(" %d", f[q]) : printf(" -"); printf(" ]  %s %s\n", hit ? "hit" : "FAULT", note); }
    }
    return faults;
}
static int clockalg(const int *ref, int len, int frames, int trace)
{
    int f[MAXF], bit[MAXF], used = 0, hand = 0, faults = 0;
    for (int i = 0; i < len; i++) {
        int k = find(f, used, ref[i]); int hit = k >= 0; char note[32] = "";
        if (hit) bit[k] = 1;                                   /* the hardware sets the reference bit */
        else { faults++; if (used < frames) { f[used] = ref[i]; bit[used++] = 1; }
            else { while (bit[hand]) { bit[hand] = 0; hand = (hand + 1) % frames; }   /* give a second chance */
                   snprintf(note, sizeof note, "evict %d", f[hand]); f[hand] = ref[i]; bit[hand] = 1; hand = (hand + 1) % frames; } }
        if (trace) { printf("%2d: ref %d  [", i + 1, ref[i]); for (int q = 0; q < frames; q++) q < used ? printf(" %d/%d", f[q], bit[q]) : printf(" -"); printf(" ]  %s %s\n", hit ? "hit" : "FAULT", note); }
    }
    return faults;
}
/* strong locality: 90% of references go to a working set of 6 pages that drifts every 2000 references, 10% anywhere */
static void gen_locality(int *r, int n, unsigned seed){ srand(seed); int base = 0; for (int i = 0; i < n; i++) { if (i % 2000 == 0) base = rand() % PAGES; r[i] = (rand() % 100 < 90) ? (base + rand() % 6) % PAGES : rand() % PAGES; } }
static void gen_random(int *r, int n, unsigned seed){ srand(seed); for (int i = 0; i < n; i++) r[i] = rand() % PAGES; }
int main(int argc, char **argv)
{
    const char *m = argc > 1 ? argv[1] : "ref";
    int ref20[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
    int bel[] = {1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5};
    if (!strcmp(m, "trace")) { puts("FIFO, 3 frames"); printf("total faults = %d\n\nLRU, 3 frames\n", fifo(ref20, 20, 3, 1)); printf("total faults = %d\n\nOptimal, 3 frames\n", lru(ref20, 20, 3, 1)); printf("total faults = %d\n\nClock, 3 frames (frame page/refbit)\n", optimal(ref20, 20, 3, 1)); printf("total faults = %d\n", clockalg(ref20, 20, 3, 1)); }
    else if (!strcmp(m, "ref") || !strcmp(m, "belady")) { int *r = !strcmp(m, "ref") ? ref20 : bel, n = !strcmp(m, "ref") ? 20 : 12; puts("frames,FIFO,LRU,Optimal,Clock"); for (int fr = 1; fr <= 7; fr++) printf("%d,%d,%d,%d,%d\n", fr, fifo(r, n, fr, 0), lru(r, n, fr, 0), optimal(r, n, fr, 0), clockalg(r, n, fr, 0)); }
    else if (!strcmp(m, "curve")) {
        const int N = 10000; static int r[100000]; int loc = argc > 2 && !strcmp(argv[2], "locality");
        puts("frames,FIFO,LRU,Optimal,Clock");
        for (int fr = 3; fr <= 10; fr++) { long a = 0, b = 0, c = 0, d = 0; for (unsigned s = 1; s <= 5; s++) { (loc ? gen_locality : gen_random)(r, N, s); a += fifo(r, N, fr, 0); b += lru(r, N, fr, 0); c += optimal(r, N, fr, 0); d += clockalg(r, N, fr, 0); } printf("%d,%ld,%ld,%ld,%ld\n", fr, a / 5, b / 5, c / 5, d / 5); }   /* mean of 5 strings of 10,000 refs */
    }
    else if (!strcmp(m, "time")) {
        const int N = 100000; static int r[100000]; gen_locality(r, N, 1); int fr = 8; double t; int x;
        printf("100,000 references, locality string, %d frames (median of 7 runs, ms) and faults\n", fr);
        const char *nm[4] = {"FIFO", "LRU", "Optimal", "Clock"};
        for (int a = 0; a < 4; a++) { double ts[7]; for (int k = 0; k < 7; k++) { t = now(); x = a == 0 ? fifo(r, N, fr, 0) : a == 1 ? lru(r, N, fr, 0) : a == 2 ? optimal(r, N, fr, 0) : clockalg(r, N, fr, 0); ts[k] = (now() - t) * 1000; }
            for (int i = 0; i < 7; i++) for (int j = i + 1; j < 7; j++) if (ts[j] < ts[i]) { double q = ts[i]; ts[i] = ts[j]; ts[j] = q; }
            printf("%-8s %9.3f ms  faults %d\n", nm[a], ts[3], x); }
    }
    return 0;
}
