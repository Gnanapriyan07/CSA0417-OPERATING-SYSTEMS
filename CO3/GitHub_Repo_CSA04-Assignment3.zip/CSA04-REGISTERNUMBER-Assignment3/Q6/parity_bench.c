/* Q6 alternative: cost of computing parity for one stripe.
   RAID 5 (6 disks): 5 data blocks + P  (P = XOR).
   RAID 6 (6 disks): 4 data blocks + P (XOR) + Q (Reed-Solomon over GF(2^8), generator 2, Horner's rule).
   Block size 64 KiB per disk (stripe unit); the time to compute parity for a FULL stripe is measured. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#define BS 65536
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
static void raid5(uint8_t **d, int n, uint8_t *p){ memcpy(p, d[0], BS); for (int i = 1; i < n; i++) for (size_t k = 0; k < BS; k++) p[k] ^= d[i][k]; }
static void raid6(uint8_t **d, int n, uint8_t *p, uint8_t *q)
{
    memcpy(p, d[n-1], BS); memcpy(q, d[n-1], BS);
    for (int i = n - 2; i >= 0; i--) for (size_t k = 0; k < BS; k++) { p[k] ^= d[i][k]; uint8_t x = q[k]; q[k] = (uint8_t)((x << 1) ^ (uint8_t)(((x >> 7) & 1) * 0x1d)) ^ d[i][k]; }   /* Q = sum g^i * D_i */
}
int main(void)
{
    uint8_t *blk[5], *p = malloc(BS), *q = malloc(BS); for (int i = 0; i < 5; i++) { blk[i] = malloc(BS); for (size_t k = 0; k < BS; k++) blk[i][k] = (uint8_t)rand(); }
    const int R = 2000; double t = now(); for (int r = 0; r < R; r++) raid5(blk, 5, p); double a = (now() - t) / R;
    t = now(); for (int r = 0; r < R; r++) raid6(blk, 4, p, q); double b = (now() - t) / R;
    /* verify RAID 6 can rebuild two lost blocks is out of scope; verify P by recomputation */
    uint8_t chk = 0; for (int i = 0; i < 4; i++) chk ^= blk[i][100]; chk ^= p[100]; 
    printf("full-stripe parity, 64 KiB per disk (mean of %d runs, gcc -O3 auto-vectorised)\n", R);
    printf("RAID 5 (5 data -> P)          : %8.1f us per stripe (%.2f GB/s of data)\n", a * 1e6, 5.0 * BS / a / 1e9);
    printf("RAID 6 (4 data -> P and Q)    : %8.1f us per stripe (%.2f GB/s of data)\n", b * 1e6, 4.0 * BS / b / 1e9);
    printf("RAID 6 / RAID 5 parity time per KiB of data = %.2f x ; P check byte = %u (0 = consistent)\n", (b / (4.0 * BS)) / (a / (5.0 * BS)), chk);
    return 0;
}
