#!/usr/bin/env python3
"""Q6: usable capacity of 6 x 4 TB disks and probability of data loss (formulas shown in the report)."""
from math import comb
N, TB = 6, 4
print("== Usable capacity, 6 disks x 4 TB")
cap = {"RAID 0":N*TB, "RAID 1 (3 mirrored pairs)":N//2*TB, "RAID 1 (one 6-way mirror)":TB, "RAID 5":(N-1)*TB, "RAID 6":(N-2)*TB, "RAID 10":N//2*TB}
tol  = {"RAID 0":"0","RAID 1 (3 mirrored pairs)":"1 per pair (min 1, max 3)","RAID 1 (one 6-way mirror)":"5","RAID 5":"1","RAID 6":"2","RAID 10":"1 per mirror pair (min 1, max 3)"}
for k,v in cap.items(): print(f"{k:28s} {v:3d} TB usable ({100*v/(N*TB):5.1f}% of 24 TB)  survives {tol[k]} failure(s)")
print("\n== Probability of data loss (assumptions: independent disks, annual failure rate AFR = 2 %, rebuild window = 24 h,")
print("   ignoring unrecoverable read errors; loss = further failures inside the rebuild window)")
AFR, hours = 0.02, 24
p = AFR * hours / 8760            # probability one given disk fails during the rebuild window
print(f"probability that one given surviving disk fails during a 24 h rebuild: p = {p:.3e}")
# probability that a first failure happens in a year (any of 6 disks)
first = 1 - (1-AFR)**N; print(f"probability at least one of the 6 disks fails in a year: {first:.4f}")
r1  = p                                  # RAID1 pair / RAID10: the single mirror partner must fail
r5  = 1 - (1-p)**(N-1)                   # RAID5: any of the 5 others
r6  = sum(comb(N-1,k)*p**k*(1-p)**(N-1-k) for k in range(2, N))   # RAID6: 2 or more of the 5 others
r10 = p
for name, v in (("RAID 1 / RAID 10 (mirror partner fails)", r1), ("RAID 5 (any of 5 others fails)", r5), ("RAID 6 (2+ of 5 others fail)", r6)):
    print(f"{name:42s} P(loss | one disk failed) = {v:.3e}   per year (x first-failure prob.) = {v*first:.3e}")
print(f"RAID 5 is {r5/r1:.1f}x more likely to lose data than RAID 1/10 per failure event; RAID 6 is {r1/r6:,.0f}x less likely than RAID 1/10.")
print("RAID 0: any single failure loses everything: P(loss per year) =", f"{first:.4f}")
