/* Q4: random access to a file-backed mapping of W MB, run inside a memory-limited cgroup.
   Once W exceeds the limit, pages are evicted and re-read from disk (major faults): demand paging beyond RAM.
   Usage: ws_mem <file> <W_MB> <accesses> */
#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/resource.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
int main(int argc, char **argv)
{
    if (argc < 4) return 2;
    size_t w = (size_t)atol(argv[2]) << 20, n = (size_t)atol(argv[3]), pages = w / 4096;
    int fd = open(argv[1], O_RDONLY); if (fd < 0) { perror("open"); return 1; }
    volatile unsigned char *p = mmap(NULL, w, PROT_READ, MAP_PRIVATE, fd, 0); if (p == MAP_FAILED) { perror("mmap"); return 1; }
    madvise((void *)p, w, MADV_RANDOM);                       /* no read-ahead: one page per fault */
    unsigned long sum = 0;
    for (size_t i = 0; i < pages; i++) sum += p[i * 4096];    /* warm-up: sequential pass */
    struct rusage a, b; getrusage(RUSAGE_SELF, &a); double t0 = now();
    unsigned long long x = 88172645463325252ull;
    for (size_t k = 0; k < n; k++) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; sum += p[(x % pages) * 4096]; }
    double t = now() - t0; getrusage(RUSAGE_SELF, &b);
    long mi = b.ru_minflt - a.ru_minflt, ma = b.ru_majflt - a.ru_majflt;
    printf("W=%4zu MB  accesses=%zu  time=%8.3f s  per access=%9.1f ns  minor=%ld major=%ld  fault rate=%.6f  (sum %lu)\n", w >> 20, n, t, t / n * 1e9, mi, ma, (double)(mi + ma) / n, sum & 1);
    return 0;
}
