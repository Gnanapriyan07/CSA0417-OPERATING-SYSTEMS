/* Q4: copy-on-write. Parent allocates and touches 256 MB, forks; the child reports its memory (Rss, Pss,
   Private_Dirty from /proc/self/smaps_rollup) before writing, after writing 25 % and after writing 100 %. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/resource.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
static void report(const char *tag)
{
    FILE *f = fopen("/proc/self/smaps_rollup", "r"); char l[128]; long rss = 0, pss = 0, pd = 0, sd = 0; struct rusage r; getrusage(RUSAGE_SELF, &r);
    while (f && fgets(l, sizeof l, f)) { sscanf(l, "Rss: %ld", &rss); sscanf(l, "Pss: %ld", &pss); sscanf(l, "Private_Dirty: %ld", &pd); sscanf(l, "Shared_Dirty: %ld", &sd); }
    if (f) fclose(f);
    printf("child %-22s Rss=%7ld kB  Pss=%7ld kB  Private_Dirty=%7ld kB  Shared_Dirty=%7ld kB  minor faults=%ld\n", tag, rss, pss, pd, sd, r.ru_minflt); fflush(stdout);
}
int main(void)
{
    size_t mb = 256, n = mb << 20; char *p = mmap(NULL, n, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    memset(p, 7, n);                                           /* parent touches everything */
    double t = now(); void *cp = malloc(n); memcpy(cp, p, n); double tcopy = now() - t;   /* what copying 256 MB would cost */
    t = now(); pid_t c = fork(); if (c == 0) {
        double tf = now() - t; (void)tf; report("just after fork");
        for (size_t i = 0; i < n / 4; i += 4096) { p[i] = 9; }
        report("after writing 25 %");
        for (size_t i = 0; i < n; i += 4096) { p[i] = 9; }
        report("after writing 100 %");
        _exit(0); }
    double tfork = now() - t; waitpid(c, NULL, 0);
    printf("fork() of a 256 MB process took %.3f ms; memcpy of 256 MB takes %.1f ms (%.0fx longer)\n", tfork * 1000, tcopy * 1000, tcopy / tfork);
    return 0;
}
