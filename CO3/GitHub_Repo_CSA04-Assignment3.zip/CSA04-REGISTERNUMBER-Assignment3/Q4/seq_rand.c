/* Q4: touch memory in sequential and random page order and count page faults + time.
   Usage: seq_rand <MB>   (anonymous memory: first touch of every page = one minor fault) */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/resource.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
static long minflt(void){ struct rusage r; getrusage(RUSAGE_SELF,&r); return r.ru_minflt; }
int main(int argc, char **argv)
{
    size_t mb = argc > 1 ? (size_t)atol(argv[1]) : 256, pages = (mb << 20) / 4096;
    for (int order = 0; order < 2; order++) {
        char *p = mmap(NULL, mb << 20, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p == MAP_FAILED) { perror("mmap"); return 1; }
        size_t *perm = malloc(pages * sizeof *perm);
        for (size_t i = 0; i < pages; i++) perm[i] = i;
        if (order) { srand(5); for (size_t i = pages - 1; i > 0; i--) { size_t j = ((size_t)rand() * 32768 + rand()) % (i + 1); size_t t = perm[i]; perm[i] = perm[j]; perm[j] = t; } }
        long f0 = minflt(); double t0 = now();
        for (size_t i = 0; i < pages; i++) p[perm[i] * 4096] = 1;               /* first touch */
        double t1 = now(); long f1 = minflt();
        for (size_t i = 0; i < pages; i++) p[perm[i] * 4096] += 1;              /* second pass: already resident */
        double t2 = now(); long f2 = minflt();
        printf("%-10s %4zu MB (%zu pages): first pass %7.1f ms, %6ld faults | second pass %7.1f ms, %ld faults\n", order ? "random" : "sequential", mb, pages, (t1 - t0) * 1000, f1 - f0, (t2 - t1) * 1000, f2 - f1);
        free(perm); munmap(p, mb << 20);
    }
    return 0;
}
