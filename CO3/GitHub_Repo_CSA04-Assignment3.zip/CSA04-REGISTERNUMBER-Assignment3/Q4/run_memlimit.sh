#!/bin/bash
# Run ws_mem inside a memory cgroup (v1) with a 128 MB limit; W = working-set size in MB.
LIMIT_MB=${1:-128}; CG=/sys/fs/cgroup/memory/q4; mkdir -p $CG
echo $((LIMIT_MB*1024*1024)) > $CG/memory.limit_in_bytes
sync
echo "memory limit = $LIMIT_MB MB (cgroup), file /tmp/data512.bin, 200,000 random page accesses after warm-up"
for W in 32 64 96 112 128 144 160 192 256 384; do
  sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
  bash -c "echo \$\$ > $CG/cgroup.procs; exec ./ws_mem /tmp/data512.bin $W 200000"
done
