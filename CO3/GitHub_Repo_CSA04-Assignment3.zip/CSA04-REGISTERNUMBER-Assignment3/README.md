# CSA04-<RegisterNumber>-Assignment3

**Assignment:** CSA04 Operating Systems – Assignment 3 (CO3): Memory management (linking/loading, paging, segmentation, virtual memory, page replacement, disk management, real-time memory design)

| Field | Value |
|---|---|
| Name | **FILL IN: your full name** |
| Register number | **FILL IN: your register number** |
| Faculty | **FILL IN: faculty name** |
| Compiler | gcc 13.3.0 (Ubuntu 13.3.0-6ubuntu2~24.04.1) |
| Linux distribution | Ubuntu 24.04.5 LTS, kernel 6.18 (1 virtual CPU, 4 GB RAM) |
| Tools | strace 6.8, GNU time 1.9, Python 3, fdisk, util-linux |
| Compile command | `gcc -std=c11 -Wall -Wextra -o <name> <name>.c` (Q1 uses `-std=gnu11`, `-ldl`; Q4/Q6 benchmarks use `-O1`/`-O3`) |

> If you re-run the programs on your own machine, replace the compiler/distribution rows with your own.

## Folder layout
One folder per question (`Q1` … `Q7`): C sources, scripts, and the saved command outputs. The full report is in `Report/`, figures in `figures/`.

## How to run
```bash
# Q1  (build static / dynamic / dlopen versions, then run the experiments)
cd Q1
gcc -std=gnu11 -fPIC -shared -o libbankenc.so bankenc_v1.c && cp libbankenc.so libbankenc_v1.so
gcc -fPIC -shared -o libbankenc_v2.so bankenc_v2.c
gcc -std=gnu11 -Wall -Wextra -o bank_dynamic bank.c -L. -lbankenc -Wl,-rpath,'$ORIGIN'
gcc -std=gnu11 -Wall -Wextra -static -o bank_static bank.c bankenc_v1.c
gcc -std=gnu11 -Wall -Wextra -o dl_bank dl_bank.c -ldl
sudo python3 q1_experiments.py          # needs: sudo apt install time
# Q2 (completed TODO 1)
cd ../Q2 && gcc -std=c11 -Wall -Wextra -o paging paging.c && ./paging
gcc -std=c11 -Wall -Wextra -o paging_2048 paging_2048.c && ./paging_2048
gcc -std=c11 -Wall -Wextra -o paging_boundary paging_boundary.c && ./paging_boundary
gcc -std=c11 -Wall -Wextra -o frag_eat frag_eat.c -lm && ./frag_eat
gcc -std=c11 -O1 -Wall -Wextra -o pt_bench pt_bench.c && ./pt_bench
# Q3
cd ../Q3 && gcc -std=c11 -Wall -Wextra -o segtrans segtrans.c && ./segtrans
gcc -std=gnu11 -O0 -Wall -Wextra -Wno-infinite-recursion -o segfault_demo segfault_demo.c && ./segfault_demo handler
gcc -std=c11 -Wall -Wextra -o frag_seg frag_seg.c && ./frag_seg
gcc -std=gnu11 -Wall -Wextra -o maps_demo maps_demo.c && ./maps_demo
# Q4 (cgroup parts need root and cgroup v1; see report Appendix B)
cd ../Q4 && gcc -std=c11 -O1 -Wall -Wextra -o seq_rand seq_rand.c && ./seq_rand 256
gcc -std=c11 -O1 -Wall -Wextra -o cow_demo cow_demo.c && ./cow_demo
gcc -std=c11 -O1 -Wall -Wextra -o ws_mem ws_mem.c && head -c 512M /dev/urandom > /tmp/data512.bin && sudo ./run_memlimit.sh 128
# Q5 (completed TODO 1)
cd ../Q5 && gcc -std=c11 -Wall -Wextra -o replace replace.c && ./replace
gcc -std=c11 -O2 -Wall -Wextra -o pagesim pagesim.c && ./pagesim curve locality && python3 verify_by_hand.py
# Q6
cd ../Q6 && python3 raid_calc.py && gcc -std=c11 -O3 -march=x86-64-v2 -o parity_bench parity_bench.c && ./parity_bench
lsblk; sudo fdisk -l; swapon --show; free -h
# Q7 (needs root and cgroup v1)
cd ../Q7 && gcc -std=gnu11 -O1 -o rt_loop rt_loop.c && gcc -std=gnu11 -O1 -o hog hog.c && sudo ./run_rt_test.sh 5000
gcc -std=c11 -O2 -o memsim memsim.c && ./memsim A 1 && ./memsim B 1
```

## Results per question
| Q | Result |
|---|---|
| 1 | Dynamic linking: fix = 15,232-byte library vs 21.76 MB static executable; start-up 0.809 ms vs 0.616 ms (static); dlopen on demand 0.676 ms; missing library handled with own error |
| 2 | Completed paging program matches expected output; 4 KB pages waste 1.99 KB/process; EAT 114 ns at 99 % TLB hits (4 levels) |
| 3 | 8 segment addresses verified; external fragmentation 44–53 %; segmentation-fault trace with strace |
| 4 | EAT 8,099.9 / 180 / 108 ns; max fault rate for 10 % loss 1 in 800,000; knee at the 128 MB cgroup limit; fork of 256 MB takes 3.3 ms vs 160 ms copy |
| 5 | FIFO 15 / LRU 12 / Optimal 9 (3 frames) matches expected; Belady anomaly 9 -> 10; clock recommended |
| 6 | RAID 10 recommended; RAID capacity and loss probability calculated; SSD vs HDD comparison NOT EXECUTED (one virtual disk only) |
| 7 | mlockall: worst iteration 22–27 µs and 0 page faults vs 1.7–10.8 ms and ~12,500 faults unlocked |

Measurements were taken in a one-CPU virtual machine; see the report for limits and for the items marked NOT EXECUTED.
