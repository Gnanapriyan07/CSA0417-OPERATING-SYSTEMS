/* Trigger real segmentation faults and show what the OS reports.
   Usage: segfault_demo null | rodata | stack | handler */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
static void h(int sig, siginfo_t *si, void *u){ (void)u;
    char b[160]; int n = snprintf(b, sizeof b, "SIGSEGV caught: si_code=%s, faulting address=%p\n", si->si_code == SEGV_MAPERR ? "SEGV_MAPERR (address not mapped)" : "SEGV_ACCERR (permission violation)", si->si_addr);
    write(2, b, n); _exit(sig == SIGSEGV ? 139 : 1); }
static int rec(int n){ volatile char big[65536]; big[0] = n; return rec(n + 1) + big[0]; }
int main(int argc, char **argv)
{
    const char *m = argc > 1 ? argv[1] : "null";
    if (!strcmp(m, "handler")) { struct sigaction sa; memset(&sa, 0, sizeof sa); sa.sa_sigaction = h; sa.sa_flags = SA_SIGINFO; sigaction(SIGSEGV, &sa, NULL); m = "null"; }
    printf("mode %s; about to fault\n", m); fflush(stdout);
    if (!strcmp(m, "null")) { volatile int *p = NULL; *p = 1; }                              /* unmapped page */
    else if (!strcmp(m, "rodata")) { char *s = (char *)"read-only literal"; s[0] = 'X'; }     /* write to read-only segment */
    else if (!strcmp(m, "stack")) return rec(0);                                              /* stack overflow */
    return 0;
}
