/* Segment-table address translation: (segment, offset) -> physical address, with limit check. */
#include <stdio.h>
typedef struct { const char *name; unsigned base, limit; int perm_w; } seg_t;
static const seg_t table[5] = {
    {"code",   1400, 1000, 0},   /* read-only, shared */
    {"data",   6300,  400, 1},
    {"stack",  4300,  400, 1},
    {"heap",   3200, 1100, 1},
    {"library",4700, 1000, 0},
};
static void translate(unsigned s, unsigned off, int write)
{
    printf("(%u, %4u) %-5s : ", s, off, write ? "write" : "read");
    if (s >= 5) { printf("TRAP: invalid segment number\n"); return; }
    if (off >= table[s].limit) { printf("TRAP (segmentation fault): offset %u >= limit %u of %s\n", off, table[s].limit, table[s].name); return; }
    if (write && !table[s].perm_w) { printf("TRAP (protection fault): %s is read-only\n", table[s].name); return; }
    printf("%s base %u + %u = physical %u\n", table[s].name, table[s].base, off, table[s].base + off);
}
int main(void)
{
    struct { unsigned s, off; int w; } t[8] = {
        {0, 53, 0}, {1, 852, 0}, {2, 399, 1}, {3, 1099, 0}, {4, 0, 0}, {2, 400, 0}, {0, 100, 1}, {5, 10, 0} };
    for (int i = 0; i < 8; i++) translate(t[i].s, t[i].off, t[i].w);
    return 0;
}
