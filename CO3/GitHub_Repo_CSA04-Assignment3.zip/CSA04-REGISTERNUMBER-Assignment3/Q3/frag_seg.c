/* Q3 experiment: external fragmentation of segmentation.
   1,024 KB of memory; load 20 segments of random size (8..96 KB) by first fit; remove 10 random ones;
   then report holes. Repeats for 5 seeds. */
#include <stdio.h>
#include <stdlib.h>
#define MEM 1024
typedef struct { int base, size, live; } seg_t;
static char used[MEM];            /* 1 KB granularity */
static int fit(int size){ int run = 0; for (int i = 0; i < MEM; i++) { run = used[i] ? 0 : run + 1; if (run == size) return i - size + 1; } return -1; }
int main(void)
{
    for (int seed = 1; seed <= 5; seed++) {
        srand(seed); for (int i = 0; i < MEM; i++) used[i] = 0;
        seg_t s[20]; int loaded = 0;
        for (int i = 0; i < 20; i++) { s[i].size = 8 + rand() % 89; s[i].base = fit(s[i].size); s[i].live = s[i].base >= 0; if (s[i].live) { for (int k = 0; k < s[i].size; k++) used[s[i].base + k] = 1; loaded++; } }
        int removed = 0; for (int tries = 0; removed < 10 && tries < 1000; tries++) { int i = rand() % 20; if (s[i].live) { for (int k = 0; k < s[i].size; k++) used[s[i].base + k] = 0; s[i].live = 0; removed++; } }
        int holes = 0, freeT = 0, largest = 0, run = 0;
        for (int i = 0; i <= MEM; i++) { if (i < MEM && !used[i]) { run++; freeT++; } else if (run) { holes++; if (run > largest) largest = run; run = 0; } }
        int want = largest + 1; if (want > freeT) want = freeT;   /* a new segment just bigger than the largest hole */
        printf("seed %d: loaded %2d, removed %2d | free %3d KB in %2d holes, largest hole %3d KB | external fragmentation = %5.1f%% | new %3d KB segment %s\n",
               seed, loaded, removed, freeT, holes, largest, 100.0 * (freeT - largest) / freeT, want, fit(want) < 0 && want <= freeT ? "FAILS although enough total free memory" : "fits");
    }
    return 0;
}
