/* Show the segments (mappings) of a running program: code, data/bss, heap, mmap, stack. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
int global_init = 42;            /* .data */
int global_bss[1000];            /* .bss  */
int main(void)
{
    int local = 1;                                   /* stack */
    char *heap = malloc(1 << 20);                    /* heap (brk or mmap) */
    void *m = mmap(NULL, 1 << 20, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    heap[0] = 1; ((char *)m)[0] = 1;
    printf("address of main (code)       = %p\naddress of global_init (data) = %p\naddress of global_bss (bss)   = %p\naddress of malloc'd heap      = %p\naddress of mmap region        = %p\naddress of local (stack)      = %p\n", (void *)main, (void *)&global_init, (void *)global_bss, (void *)heap, m, (void *)&local);
    printf("--- /proc/%d/maps ---\n", (int)getpid()); fflush(stdout);
    char cmd[64]; snprintf(cmd, sizeof cmd, "cat /proc/%d/maps", (int)getpid()); system(cmd);
    return 0;
}
