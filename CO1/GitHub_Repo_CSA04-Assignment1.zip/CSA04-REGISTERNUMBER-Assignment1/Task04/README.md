# Task 04 – OS services

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 6.

**Result in one paragraph:** Service table per environment; monitors drop GUI, login, accounting and general file systems; reduced handheld OS meets an 8-hour shift in the power model, a desktop OS does not.
