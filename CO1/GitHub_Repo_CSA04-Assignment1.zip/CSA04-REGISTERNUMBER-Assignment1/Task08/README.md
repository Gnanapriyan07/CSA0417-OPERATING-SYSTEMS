# Task 08 – CPU states and protection

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 10.

**Result in one paragraph:** Mode bit, privileged instructions, interrupts/traps/timer, MMU page-table isolation; polling worst-case delay equals the interval, interrupts give microsecond latency.
