/* Task 6/3: cost of an ordinary function call vs a system call vs a
   message round trip between two processes (pipe ping-pong, a proxy for
   microkernel IPC). Compile with -O0 so the calls are not optimised away. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/syscall.h>
#include <sys/wait.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
__attribute__((noinline)) static long plain(long x){ return x + 1; }
int main(void)
{
    const long N = 5000000; volatile long sink = 0;
    double t = now();
    for (long i = 0; i < N; i++) sink += plain(i);
    double f = (now() - t) / N * 1e9;
    t = now();
    for (long i = 0; i < N; i++) sink += syscall(SYS_getppid);
    double s = (now() - t) / N * 1e9;

    int a[2], b[2]; if (pipe(a) || pipe(b)) return 1;
    const long M = 100000; char c = 'x';
    pid_t p = fork();
    if (p == 0) { for (long i = 0; i < M; i++) { if (read(a[0], &c, 1) != 1) _exit(1); if (write(b[1], &c, 1) != 1) _exit(1); } _exit(0); }
    t = now();
    for (long i = 0; i < M; i++) { if (write(a[1], &c, 1) != 1) return 1; if (read(b[0], &c, 1) != 1) return 1; }
    double m = (now() - t) / M * 1e9;
    waitpid(p, NULL, 0);
    printf("function call : %8.1f ns\nsystem call   : %8.1f ns  (%.0fx a function call)\nIPC round trip: %8.1f ns  (%.1fx a system call)\n", f, s, s / f, m, m / s);
    return 0;
}
