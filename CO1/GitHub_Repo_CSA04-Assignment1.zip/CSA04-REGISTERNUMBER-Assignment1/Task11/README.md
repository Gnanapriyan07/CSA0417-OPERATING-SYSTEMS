# Task 11 – Final recommendation

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 13.

**Result in one paragraph:** Complete OS plan table with evidence from measurements, risks, scalability to three hospitals, and the virtual-machine alternative.
