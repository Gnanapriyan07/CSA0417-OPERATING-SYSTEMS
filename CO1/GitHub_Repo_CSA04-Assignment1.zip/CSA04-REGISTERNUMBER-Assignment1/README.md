# CSA04-<RegisterNumber>-Assignment1

**Assignment:** CSA0417 Operating Systems – Assignment 1 (CO1): Evaluate and Justify the Operating-System Design of a Smart Hospital

| Field | Value |
|---|---|
| Name | **FILL IN: your full name** |
| Register number | **FILL IN: your register number** |
| Faculty | **FILL IN: faculty name** |
| Compiler | gcc 13.3.0 (Ubuntu 13.3.0-6ubuntu2~24.04.1) |
| Linux distribution | Ubuntu 24.04.5 LTS, kernel 6.18 (1 virtual CPU) |
| Tools | strace 6.8, GNU time 1.9, Python 3 |
| Compile command | `gcc -std=c11 -Wall -Wextra -pthread -o <name> <name>.c` |

> If you re-run the programs on your own machine, replace the compiler/distribution rows with your own.

## Folder layout
One folder per task (`Task01` … `Task12`). Tasks with code: 05, 06, 07, 10. The full report is in `Report/`.

## How to run
```bash
# Task 5
cd Task05 && gcc -std=c11 -Wall -Wextra -o read_demo read_demo.c && strace ./read_demo
gcc -std=c11 -Wall -Wextra -o stdio_demo stdio_demo.c && ./stdio_demo
# Task 6 (completed TODO 1)
cd ../Task06 && gcc -std=c11 -Wall -Wextra -pthread -o copy_file copy_file.c && ./copy_file
strace -c -f ./copy_file > /dev/null
gcc -std=c11 -O0 -Wall -Wextra -o syscall_cost syscall_cost.c && ./syscall_cost
# Task 7 (completed TODO 1)
cd ../Task07 && gcc -std=c11 -Wall -Wextra -o shell_demo shell_demo.c && ./shell_demo
gcc -std=c11 -Wall -Wextra -o shell_demo_variant shell_demo_variant.c && ./shell_demo_variant > out.txt && cat out.txt
gcc -std=c11 -Wall -Wextra -o zombie_orphan zombie_orphan.c && ./zombie_orphan
gcc -std=c11 -Wall -Wextra -o spawn_bench spawn_bench.c && ./spawn_bench 1000
# Task 10 (needs: sudo apt install strace time)
cd ../Task10 && ./run_experiments.sh && python3 timing_hires.py
```

## Results per task
| Task | Result |
|---|---|
| 1–4, 8, 9, 11 | Analytical; see each folder README and the report |
| 5 | strace shows open/read/write/close; stdio makes 6 read calls for a 12,813-byte file |
| 6 | Output `10001 / 21 / 4` read() calls, matching the expected output; strace -c reports 10,027 (one extra read by the dynamic loader) |
| 7 | Output matches expected; removing the second fflush and using exit(3) duplicates buffered lines when redirected to a file |
| 10 | read calls = ceil(n/b)+1; 64 KiB buffer fastest tested; 1,000 threads about 5.6x faster than 1,000 processes (small parent), about 300x with a 256 MB parent |
| 12 | Decision: modify the design (home RTOS devices, DMZ gateway, cloud records with local replica) |

Measurements were taken in a one-CPU virtual machine with files in the page cache.
