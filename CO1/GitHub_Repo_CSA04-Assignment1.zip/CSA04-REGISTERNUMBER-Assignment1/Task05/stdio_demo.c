#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
int main(void){ FILE *f=fopen("/etc/services","r"); if(!f){perror("fopen");return 1;}
  char b[16]; size_t n, tot=0; while((n=fread(b,1,sizeof b,f))>0){ tot+=n; } fclose(f); printf("%zu bytes read in 16-byte fread() calls\n",tot); return 0; }
