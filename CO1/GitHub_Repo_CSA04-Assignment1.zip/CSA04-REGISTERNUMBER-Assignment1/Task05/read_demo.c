#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
/* Smallest useful program for strace: open, read, write, close. */
int main(void)
{
    int fd = open("/etc/hostname", O_RDONLY);
    if (fd < 0) { perror("open"); return 1; }
    char buf[64];
    ssize_t n = read(fd, buf, sizeof buf);
    if (n > 0) write(STDOUT_FILENO, buf, (size_t)n);
    close(fd);
    return 0;
}
