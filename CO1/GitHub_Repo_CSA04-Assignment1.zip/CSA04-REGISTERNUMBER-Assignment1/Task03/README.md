# Task 03 – Operating-system structures

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 5.

**Result in one paragraph:** Microkernel RTOS for monitors (IPC about 2.1 us measured, under 0.2% of the 10 ms deadline); monolithic kernel with loadable modules for the database server.
