# Task 12 – Design challenge (home monitoring + cloud)

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 14.

**Result in one paragraph:** Decision: MODIFY the design. Add an embedded RTOS on home devices with local alarms, a DMZ gateway, cloud records with a local replica, and identity-based security.
