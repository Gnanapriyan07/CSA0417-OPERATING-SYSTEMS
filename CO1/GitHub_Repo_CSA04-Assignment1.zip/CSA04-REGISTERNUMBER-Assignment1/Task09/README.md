# Task 09 – Memory hierarchy and I/O

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 11.

**Result in one paragraph:** Data-placement plan; DMA for MRI: 8,000 interrupts and 0.056 s CPU versus 131,072,000 interrupts and 262.1 s CPU for per-word interrupt I/O (stated assumptions).
