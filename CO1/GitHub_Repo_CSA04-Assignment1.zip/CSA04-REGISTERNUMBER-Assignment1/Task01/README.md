# Task 01 – Requirements of each environment

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 3.

**Result in one paragraph:** Ranked requirement table for six environments; alarm deadline and database availability are patient-safety critical; one general-purpose OS cannot bound alarm delay, so environment-specific OSs are used.
