# Task 02 – Types of operating system

This task is analytical (no program). Full answer, tables, diagrams and calculations: `Report/Smart_Hospital_OS_Assignment.pdf`, section 4.

**Result in one paragraph:** Hard real-time OS for monitors, handheld OS for tablets, desktop OS for workstations, clustered Linux with fail-over for the database, SMP Linux for imaging, distributed system for the partner link. Cluster reduces downtime from 8.76 h/yr to about 91.5 s/yr under stated assumptions.
