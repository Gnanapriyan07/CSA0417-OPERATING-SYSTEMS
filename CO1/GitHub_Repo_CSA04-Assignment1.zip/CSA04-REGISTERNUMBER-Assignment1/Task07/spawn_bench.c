#define _DEFAULT_SOURCE
/* Time 1000 commands (/bin/true) started with fork+exec, vfork+exec and posix_spawn. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <spawn.h>
#include <time.h>
#include <sys/wait.h>
extern char **environ;
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }

int main(int argc, char **argv)
{
    int N = argc > 1 ? atoi(argv[1]) : 1000;
    char *av[] = {"true", NULL};
    double t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t p = fork();
        if (p == 0) { execv("/bin/true", av); _exit(127); }
        waitpid(p, NULL, 0);
    }
    double a = now() - t0;
    t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t p = vfork();
        if (p == 0) { execv("/bin/true", av); _exit(127); }
        waitpid(p, NULL, 0);
    }
    double b = now() - t0;
    t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t p;
        if (posix_spawn(&p, "/bin/true", NULL, NULL, av, environ)) { perror("posix_spawn"); return 1; }
        waitpid(p, NULL, 0);
    }
    double c = now() - t0;
    printf("N=%d  fork+exec=%.3f s  vfork+exec=%.3f s  posix_spawn=%.3f s\n", N, a, b, c);
    return 0;
}
