#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
/* Part 1: zombie  - child exits, parent does not wait(); ps shows state Z.
   Part 2: orphan  - parent exits first; child is re-parented (to init/subreaper). */
static void ps_of(pid_t p){ char c[64]; snprintf(c,sizeof c,"ps -o pid,ppid,stat,comm -p %d",(int)p); fflush(stdout); system(c); }
int main(void)
{
    pid_t z = fork();
    if (z == 0) _exit(0);
    sleep(1);
    printf("ZOMBIE demo (parent %d has not called wait for child %d):\n", (int)getpid(), (int)z);
    ps_of(z);
    waitpid(z, NULL, 0);
    printf("after waitpid(): ps for the child prints only the header:\n"); ps_of(z);

    pid_t o = fork();
    if (o == 0) {
        printf("ORPHAN child %d: parent before = %d\n", (int)getpid(), (int)getppid()); fflush(stdout);
        sleep(2);
        printf("ORPHAN child %d: parent after  = %d (adopted)\n", (int)getpid(), (int)getppid()); fflush(stdout);
        _exit(0);
    }
    sleep(1);
    _exit(0);                      /* parent dies while child still sleeps */
}
