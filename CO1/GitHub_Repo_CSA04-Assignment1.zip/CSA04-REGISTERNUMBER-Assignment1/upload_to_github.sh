#!/bin/bash
# Run INSIDE this folder after editing the three variables below.
# Creates progressive commits (one per task) as the assignment requires.
REGNO="REPLACE_WITH_YOUR_REGISTER_NUMBER"
GIT_NAME="REPLACE_WITH_YOUR_NAME"
GIT_EMAIL="REPLACE_WITH_YOUR_EMAIL"
set -e
[ "$REGNO" = "REPLACE_WITH_YOUR_REGISTER_NUMBER" ] && { echo "Edit the variables at the top first."; exit 1; }
sed -i "s/<RegisterNumber>/$REGNO/; s/FILL IN: your full name/$GIT_NAME/; s/FILL IN: your register number/$REGNO/" README.md
git init -q -b main; git config user.name "$GIT_NAME"; git config user.email "$GIT_EMAIL"
git add README.md .gitignore; git commit -qm "Add README and gitignore"
for t in 01 02 03 04 05 06 07 08 09 10 11 12; do
  git add Task$t; git commit -qm "Task $t: add files and results"
done
git add Report figures; git commit -qm "Add final report and figures"
echo "Done. Now create an EMPTY repo named CSA04-$REGNO-Assignment1 on github.com, then run:"
echo "  git remote add origin https://github.com/<your-username>/CSA04-$REGNO-Assignment1.git"
echo "  git push -u origin main"
echo "Then add your faculty as collaborator (or make the repo public) and paste the link on your report cover page."
