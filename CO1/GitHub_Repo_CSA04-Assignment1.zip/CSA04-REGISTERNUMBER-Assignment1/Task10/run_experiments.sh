#!/bin/bash
# Reproduce all Task 5/6/7/10 measurements. Run from the Task10 folder.
# Requires: gcc, strace, /usr/bin/time (apt install strace time)
set -u
SRC=/tmp/src8m.dat; DST=/tmp/dst.dat; REPS=5
[ -f $SRC ] || head -c 8388608 /dev/urandom > $SRC       # 8 MiB test file
OUT=results; mkdir -p $OUT
gcc -std=c11 -O0 -Wall -Wextra -pthread -o copy_bench copy_bench.c
gcc -std=c11 -O0 -Wall -Wextra -pthread -o proc_vs_thread proc_vs_thread.c

echo "== A. strace -c : read/write counts per buffer size ==" | tee $OUT/strace_summary.txt
for b in 1 512 4096 65536; do
  echo "--- sys bufsize=$b" | tee -a $OUT/strace_summary.txt
  strace -c -o $OUT/strace_sys_$b.txt ./copy_bench sys $SRC $DST $b
  head -6 $OUT/strace_sys_$b.txt | tee -a $OUT/strace_summary.txt
done
echo "--- stdio (fread/fwrite)" | tee -a $OUT/strace_summary.txt
strace -c -o $OUT/strace_stdio.txt ./copy_bench stdio $SRC $DST 4096; head -6 $OUT/strace_stdio.txt | tee -a $OUT/strace_summary.txt
echo "--- mmap" | tee -a $OUT/strace_summary.txt
strace -c -o $OUT/strace_mmap.txt ./copy_bench mmap $SRC $DST; head -8 $OUT/strace_mmap.txt | tee -a $OUT/strace_summary.txt

echo "== B. time (elapsed user sys) x$REPS ==" 
: > $OUT/time_raw.csv
run() { # label, args...
  label=$1; shift
  for r in $(seq $REPS); do
    /usr/bin/time -f "$label,%e,%U,%S" -a -o $OUT/time_raw.csv "$@" >/dev/null
  done
}
for b in 1 512 4096 65536; do run "sys_$b" ./copy_bench sys $SRC $DST $b; done
run stdio_4096 ./copy_bench stdio $SRC $DST 4096
run mmap ./copy_bench mmap $SRC $DST
cmp $SRC $DST && echo "mmap copy verified identical"

echo "== C. 1000 processes vs 1000 threads ==" | tee $OUT/proc_thread.txt
for r in $(seq $REPS); do ./proc_vs_thread 1000 0 | tee -a $OUT/proc_thread.txt; done
echo "-- with 256 MB resident in the parent" | tee -a $OUT/proc_thread.txt
for r in $(seq 3); do ./proc_vs_thread 1000 256 | tee -a $OUT/proc_thread.txt; done
/usr/bin/time -v ./proc_vs_thread 1000 0 2> $OUT/time_v_proc_thread.txt >/dev/null
grep -E "Maximum resident|Elapsed|User time|System time" $OUT/time_v_proc_thread.txt | tee -a $OUT/proc_thread.txt
rm -f $DST
