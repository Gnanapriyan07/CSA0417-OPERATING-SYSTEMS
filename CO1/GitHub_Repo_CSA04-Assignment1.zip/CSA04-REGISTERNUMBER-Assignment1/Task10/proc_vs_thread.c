/* Time the creation of N processes (fork+_exit+waitpid) and N threads
   (pthread_create+pthread_join). Usage: proc_vs_thread [N] [MB_touched]  */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <sys/wait.h>

static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec/1e9; }
static void *thr(void *a){ (void)a; return NULL; }

int main(int argc, char **argv)
{
    int N = argc > 1 ? atoi(argv[1]) : 1000;
    size_t mb = argc > 2 ? (size_t)atol(argv[2]) : 0;   /* parent memory the child could copy */
    char *big = NULL;
    if (mb) { big = malloc(mb << 20); if (!big) return 1; memset(big, 1, mb << 20); }

    double t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t p = fork();
        if (p < 0) { perror("fork"); return 1; }
        if (p == 0) _exit(0);
        waitpid(p, NULL, 0);
    }
    double tp = now() - t0;

    t0 = now();
    for (int i = 0; i < N; i++) {
        pthread_t t;
        if (pthread_create(&t, NULL, thr, NULL)) { perror("pthread_create"); return 1; }
        pthread_join(t, NULL);
    }
    double tt = now() - t0;
    printf("N=%d touched=%zuMB processes=%.4f s (%.1f us each)  threads=%.4f s (%.1f us each)  ratio=%.1fx\n",
           N, mb, tp, tp/N*1e6, tt, tt/N*1e6, tp/tt);
    free(big);
    return 0;
}
