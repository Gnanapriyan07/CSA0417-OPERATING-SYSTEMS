/* copy_bench: copy a file with read()/write() using a given buffer size,
   or with stdio (fread/fwrite), or with mmap. Prints the read() count.
   Usage: copy_bench <mode: sys|stdio|mmap> <src> <dst> [bufsize]            */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

static long copy_sys(const char *src, const char *dst, size_t bs)
{
    char *buf = malloc(bs);
    if (!buf) return -1;
    int in = open(src, O_RDONLY);
    if (in < 0) { free(buf); return -1; }
    int out = open(dst, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out < 0) { close(in); free(buf); return -1; }
    long calls = 0; ssize_t n;
    while ((n = read(in, buf, bs)) > 0) {
        calls++;
        for (ssize_t d = 0; d < n; ) {
            ssize_t w = write(out, buf + d, (size_t)(n - d));
            if (w < 0) { calls = -1; goto done; }
            d += w;
        }
    }
    if (n < 0) calls = -1; else calls++;      /* count the final read()==0 */
done:
    close(in); close(out); free(buf);
    return calls;
}

static long copy_stdio(const char *src, const char *dst, size_t bs)
{
    char *buf = malloc(bs);
    FILE *in = fopen(src, "rb"), *out = fopen(dst, "wb");
    if (!buf || !in || !out) return -1;
    size_t n;
    while ((n = fread(buf, 1, bs, in)) > 0)   /* library fills its own 4096-byte buffer */
        if (fwrite(buf, 1, n, out) != n) return -1;
    fclose(in); fclose(out); free(buf);
    return 0;                                 /* read() count is taken from strace */
}

static long copy_mmap(const char *src, const char *dst)
{
    int in = open(src, O_RDONLY);
    if (in < 0) return -1;
    struct stat st;
    if (fstat(in, &st) < 0) { close(in); return -1; }
    int out = open(dst, O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (out < 0) { close(in); return -1; }
    if (st.st_size > 0) {
        if (ftruncate(out, st.st_size) < 0) return -1;
        void *s = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, in, 0);
        void *d = mmap(NULL, st.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, out, 0);
        if (s == MAP_FAILED || d == MAP_FAILED) return -1;
        memcpy(d, s, st.st_size);             /* page faults do the I/O, not read()/write() */
        msync(d, st.st_size, MS_ASYNC);
        munmap(s, st.st_size); munmap(d, st.st_size);
    }
    close(in); close(out);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 4) { fprintf(stderr, "usage: %s sys|stdio|mmap src dst [bufsize]\n", argv[0]); return 2; }
    size_t bs = argc > 4 ? (size_t)strtoul(argv[4], NULL, 10) : 4096;
    if (bs == 0) { fprintf(stderr, "bufsize must be > 0\n"); return 2; }
    long r;
    if (!strcmp(argv[1], "sys")) r = copy_sys(argv[2], argv[3], bs);
    else if (!strcmp(argv[1], "stdio")) r = copy_stdio(argv[2], argv[3], bs);
    else if (!strcmp(argv[1], "mmap")) r = copy_mmap(argv[2], argv[3]);
    else { fprintf(stderr, "unknown mode\n"); return 2; }
    if (r < 0) { perror("copy failed"); return 1; }
    printf("mode=%s bufsize=%zu read_calls=%ld\n", argv[1], bs, r);
    return 0;
}
