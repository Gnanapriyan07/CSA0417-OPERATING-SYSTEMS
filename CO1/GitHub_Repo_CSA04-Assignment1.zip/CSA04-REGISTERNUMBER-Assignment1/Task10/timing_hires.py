#!/usr/bin/env python3
"""High-resolution timing (wall, user, sys) of copy_bench; 64 MiB file for b>=512, 8 MiB for b=1."""
import subprocess, os, time, resource, statistics as st, csv
def run(args):
    r0=resource.getrusage(resource.RUSAGE_CHILDREN); t=time.perf_counter()
    subprocess.run(args,stdout=subprocess.DEVNULL,check=True)
    w=time.perf_counter()-t; r1=resource.getrusage(resource.RUSAGE_CHILDREN)
    return w, r1.ru_utime-r0.ru_utime, r1.ru_stime-r0.ru_stime
big,small="/tmp/src64m.dat","/tmp/src8m.dat"
if not os.path.exists(big): open(big,"wb").write(os.urandom(64<<20))
cases=[("sys",1,small,8),("sys",512,big,64),("sys",4096,big,64),("sys",65536,big,64),("stdio",4096,big,64),("mmap",0,big,64)]
rows=[["mode","bufsize","file_MiB","wall_s","user_s","sys_s","wall_ms_per_MiB"]]
for mode,b,src,mb in cases:
    res=[run(["./copy_bench",mode,src,"/tmp/dst.dat"]+([str(b)] if b else [])) for _ in range(5)]
    w,u,s=[st.median(x[i] for x in res) for i in range(3)]
    rows.append([mode,b,mb,f"{w:.4f}",f"{u:.4f}",f"{s:.4f}",f"{w/mb*1000:.2f}"])
    print(rows[-1])
csv.writer(open("results/time_hires.csv","w")).writerows(rows)
os.remove("/tmp/dst.dat")
