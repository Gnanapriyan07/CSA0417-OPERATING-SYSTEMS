/* q2_rr_study.c - Round Robin quantum study (extension of q2_rr.c).
 * Same algorithm as the completed assignment program; the quantum is read from the
 * command line and the number of context switches is counted.
 * Build: gcc -std=c11 -Wall -Wextra -o q2_rr_study q2_rr_study.c
 * Run  : ./q2_rr_study 1 | ./q2_rr_study 3 | ./q2_rr_study 5 | ./q2_rr_study 20  */
#include <stdio.h>
#include <stdlib.h>
#define N 4
int main(int argc, char *argv[])
{
    const char *name[N] = {"P1", "P2", "P3", "P4"};
    int arrival[N] = {0, 1, 2, 3};
    int burst[N] = {8, 4, 9, 5};
    int quantum = argc > 1 ? atoi(argv[1]) : 3;
    if (quantum < 1) { fprintf(stderr, "quantum must be >= 1\n"); return 1; }
    int left[N], finish[N], queue[256], head = 0, tail = 0, added[N] = {0};
    for (int i = 0; i < N; i++) left[i] = burst[i];
    int time = 0, done = 0, last = -1, dispatches = 0, switches = 0;
    queue[tail++] = 0;
    added[0] = 1;
    printf("Quantum = %d\nGantt:", quantum);
    while (done < N) {
        int p = queue[head++];
        int run = left[p] < quantum ? left[p] : quantum;
        printf(" %s(%d-%d)", name[p], time, time + run);
        dispatches++;
        if (last != -1 && last != p) switches++;   /* CPU handed to a different process */
        last = p;
        time += run;
        left[p] -= run;
        for (int i = 0; i < N; i++)
            if (!added[i] && arrival[i] <= time) { queue[tail++] = i; added[i] = 1; }
        if (left[p] > 0) queue[tail++] = p;
        else { finish[p] = time; done++; }
    }
    double tw = 0, tt = 0, tr = 0;
    printf("\nProcess TAT WT\n");
    for (int i = 0; i < N; i++) {
        int tat = finish[i] - arrival[i], wt = tat - burst[i];
        tt += tat; tw += wt;
        printf("%-7s %4d %3d\n", name[i], tat, wt);
    }
    (void)tr;
    printf("Average TAT = %.2f, average WT = %.2f\n", tt / N, tw / N);
    printf("Dispatches = %d, context switches = %d\n", dispatches, switches);
    return 0;
}
