/* q6_banker_bench.c - running time of the Banker's safety algorithm for n processes.
 * Worst-case state: only one process can finish in each pass over the process list
 * (process n-1 first, then n-2, ...), so the while loop runs n times and each pass
 * scans n processes, each test failing on the LAST resource (m comparisons)
 * ->  about n^2 * m comparisons.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -o q6_bench q6_banker_bench.c
 * Run  : ./q6_bench 10 5 | ./q6_bench 100 5 | ./q6_bench 1000 5   (n, m)           */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static int is_safe(int n, int m, const int *avail, const int *maxm, const int *alloc, int *seq)
{
    int *work = malloc((size_t)m * sizeof *work);
    char *finish = calloc((size_t)n, 1);
    int count = 0;
    memcpy(work, avail, (size_t)m * sizeof *work);
    while (count < n) {
        int found = 0;
        for (int p = 0; p < n; p++) {
            if (finish[p]) continue;
            int ok = 1;
            for (int r = 0; r < m; r++)
                if (maxm[p * m + r] - alloc[p * m + r] > work[r]) { ok = 0; break; }
            if (ok) {
                for (int r = 0; r < m; r++) work[r] += alloc[p * m + r];
                finish[p] = 1; seq[count++] = p; found = 1;
            }
        }
        if (!found) { free(work); free(finish); return 0; }
    }
    free(work); free(finish);
    return 1;
}

int main(int argc, char *argv[])
{
    int n = argc > 1 ? atoi(argv[1]) : 100, m = argc > 2 ? atoi(argv[2]) : 5;
    int *avail = malloc((size_t)m * sizeof *avail);
    int *maxm = malloc((size_t)n * m * sizeof *maxm);
    int *alloc = malloc((size_t)n * m * sizeof *alloc);
    int *seq = malloc((size_t)n * sizeof *seq);
    for (int r = 0; r < m; r++) avail[r] = 1;
    for (int p = 0; p < n; p++)
        for (int r = 0; r < m; r++) {
            alloc[p * m + r] = 1;
            /* need is 1 for all resources except the last one, where need = n - p, so every
             * failing test costs m comparisons and the finishing order is n-1, n-2, ... 0 */
            maxm[p * m + r] = 1 + (r < m - 1 ? 1 : n - p);
        }
    int reps = (int)(2e8 / ((double)n * n * m)) + 1;   /* repeat for a measurable time */
    struct timespec t0, t1;
    int safe = 0;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for (int i = 0; i < reps; i++) safe = is_safe(n, m, avail, maxm, alloc, seq);
    clock_gettime(CLOCK_MONOTONIC, &t1);
    double us = ((t1.tv_sec - t0.tv_sec) * 1e9 + (t1.tv_nsec - t0.tv_nsec)) / 1e3 / reps;
    printf("n=%d m=%d: safe=%d, first=P%d last=P%d, %.2f us per safety check (%d repetitions)\n",
           n, m, safe, seq[0], seq[n - 1], us, reps);
    return 0;
}
