/* q3_race.c - lost updates on a shared counter.
 * Build: gcc -std=c11 -O1 -Wall -Wextra -pthread -o q3_race q3_race.c
 * Run  : ./q3_race unsafe 4 | ./q3_race mutex 4 | ./q3_race atomic 4            */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>
#include <pthread.h>

#define UPDATES 1000000L
static volatile long unsafe_counter = 0;      /* volatile forces a real load and store */
static long mutex_counter = 0;
static atomic_long atomic_counter = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static const char *mode;

static void *worker(void *arg)
{
    (void)arg;
    for (long i = 0; i < UPDATES; i++) {
        if (strcmp(mode, "unsafe") == 0) unsafe_counter = unsafe_counter + 1;   /* race */
        else if (strcmp(mode, "mutex") == 0) {
            pthread_mutex_lock(&lock); mutex_counter++; pthread_mutex_unlock(&lock);
        } else atomic_fetch_add(&atomic_counter, 1);
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s unsafe|mutex|atomic THREADS\n", argv[0]); return 1; }
    mode = argv[1];
    int n = atoi(argv[2]);
    pthread_t *t = malloc((size_t)n * sizeof *t);
    for (int i = 0; i < n; i++) pthread_create(&t[i], NULL, worker, NULL);
    for (int i = 0; i < n; i++) pthread_join(t[i], NULL);
    long got = strcmp(mode, "unsafe") == 0 ? unsafe_counter :
               strcmp(mode, "mutex") == 0 ? mutex_counter : atomic_load(&atomic_counter);
    printf("%s: %d threads, expected %ld, got %ld, lost %ld\n",
           mode, n, n * UPDATES, got, n * UPDATES - got);
    free(t);
    return 0;
}
