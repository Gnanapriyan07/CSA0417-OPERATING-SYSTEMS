/* q3_procs.c - alternative design: camera frames processed by several PROCESSES.
 * Results travel back to the parent through a pipe (IPC instead of shared variables).
 * Build: gcc -std=c11 -O2 -Wall -Wextra -o q3_procs q3_procs.c
 * Run  : ./q3_procs 4      (also 8, 16)                                           */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>

#define CAMERAS 64
#ifndef WORK
#define WORK 20000000L
#endif

struct msg { int cam; uint32_t value; };       /* 8 bytes: written atomically (< PIPE_BUF) */

static uint32_t read_plate(int cam)            /* identical to q3_cameras.c */
{
    uint32_t h = 2166136261u ^ (uint32_t)cam;
    for (long i = 0; i < WORK; i++) { h ^= (uint32_t)i; h *= 16777619u; }
    return h;
}

int main(int argc, char *argv[])
{
    int nproc = argc > 1 ? atoi(argv[1]) : 4;
    if (nproc < 1) return 1;
    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for (int w = 0; w < nproc; w++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {                                   /* worker process */
            close(fd[0]);
            for (int cam = w; cam < CAMERAS; cam += nproc) {   /* static partition */
                struct msg m = { cam, read_plate(cam) };
                if (write(fd[1], &m, sizeof m) != (ssize_t)sizeof m) _exit(1);
            }
            close(fd[1]);
            _exit(0);
        }
    }
    close(fd[1]);                                         /* parent reads only */
    uint32_t result[CAMERAS] = {0};
    int frames = 0;
    struct msg m;
    while (read(fd[0], &m, sizeof m) == (ssize_t)sizeof m) { result[m.cam] = m.value; frames++; }
    while (wait(NULL) > 0) { }
    clock_gettime(CLOCK_MONOTONIC, &t1);

    uint32_t checksum = 0;
    for (int c = 0; c < CAMERAS; c++) checksum ^= result[c];
    double sec = (double)(t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
    printf("mode=processes workers=%d frames=%d checksum=%08x time=%.3f s\n",
           nproc, frames, checksum, sec);
    return 0;
}
