/* q3_cameras.c - number-plate reading for 64 cameras with POSIX threads.
 * Modes: serial | perthread | pool N.  Optional last argument: simulated I/O ms/frame.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q3_cameras q3_cameras.c
 * Run  : ./q3_cameras serial
 *        ./q3_cameras perthread
 *        ./q3_cameras pool 4        (also 8, 16)
 *        ./q3_cameras pool 8 20     (20 ms simulated camera I/O per frame)         */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdatomic.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>

#define CAMERAS 64
#ifndef WORK
#define WORK 20000000L          /* loop iterations that stand in for plate recognition */
#endif

static uint32_t result[CAMERAS];       /* each camera writes only its own element */
static atomic_int next_camera = 0;     /* shared work index for the pool */
static int frames_done = 0;            /* shared counter, protected by a mutex */
static pthread_mutex_t done_lock = PTHREAD_MUTEX_INITIALIZER;
static int io_ms = 0;

static uint32_t read_plate(int cam)    /* CPU-bound stand-in for OCR (FNV-1a style hash) */
{
    uint32_t h = 2166136261u ^ (uint32_t)cam;
    for (long i = 0; i < WORK; i++) { h ^= (uint32_t)i; h *= 16777619u; }
    return h;
}

static void process_camera(int cam)
{
    if (io_ms > 0) {                                   /* waiting for the frame */
        struct timespec d = { io_ms / 1000, (long)(io_ms % 1000) * 1000000L };
        nanosleep(&d, NULL);
    }
    result[cam] = read_plate(cam);
    pthread_mutex_lock(&done_lock);
    frames_done++;
    pthread_mutex_unlock(&done_lock);
}

static void *camera_thread(void *arg)  /* one thread per camera */
{
    process_camera((int)(intptr_t)arg);
    return NULL;
}

static void *pool_worker(void *arg)    /* pool worker: keeps taking the next camera */
{
    (void)arg;
    for (;;) {
        int cam = atomic_fetch_add(&next_camera, 1);
        if (cam >= CAMERAS) break;
        process_camera(cam);
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc < 2) { fprintf(stderr, "usage: %s serial|perthread|pool N [io_ms]\n", argv[0]); return 1; }
    int nthreads = 1, ioarg = 2;
    if (strcmp(argv[1], "pool") == 0) {
        if (argc < 3) { fprintf(stderr, "pool needs N\n"); return 1; }
        nthreads = atoi(argv[2]); ioarg = 3;
        if (nthreads < 1) return 1;
    } else if (strcmp(argv[1], "perthread") == 0) nthreads = CAMERAS;
    if (argc > ioarg) io_ms = atoi(argv[ioarg]);

    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    if (strcmp(argv[1], "serial") == 0) {
        for (int c = 0; c < CAMERAS; c++) process_camera(c);
    } else {
        pthread_t *tid = malloc((size_t)nthreads * sizeof *tid);
        for (int i = 0; i < nthreads; i++) {
            if (strcmp(argv[1], "perthread") == 0)
                pthread_create(&tid[i], NULL, camera_thread, (void *)(intptr_t)i);
            else
                pthread_create(&tid[i], NULL, pool_worker, NULL);
        }
        for (int i = 0; i < nthreads; i++) pthread_join(tid[i], NULL);
        free(tid);
    }
    clock_gettime(CLOCK_MONOTONIC, &t1);

    uint32_t checksum = 0;
    for (int c = 0; c < CAMERAS; c++) checksum ^= result[c];
    double sec = (double)(t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
    printf("mode=%s threads=%d frames=%d checksum=%08x time=%.3f s\n",
           argv[1], nthreads, frames_done, checksum, sec);
    return 0;
}
