/* q4_bench.c - transfer time for a pipe versus shared memory + semaphores.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q4_bench q4_bench.c
 * Run  : ./q4_bench pipe 1 | ./q4_bench shm 1      (size in MB: 1, 10, 100)        */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>

#define CHUNK 65536
#define SLOTS 16

struct ring {
    sem_t empty, full;
    size_t len[SLOTS];
    unsigned char data[SLOTS][CHUNK];
};

static double now(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}
static int check(const unsigned char *b, size_t len, unsigned long idx)   /* cheap verify */
{
    unsigned char e = (unsigned char)(idx & 0xFF);
    return len > 0 && b[0] == e && b[len / 2] == e && b[len - 1] == e;
}

int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s pipe|shm SIZE_MB\n", argv[0]); return 1; }
    int use_pipe = strcmp(argv[1], "pipe") == 0;
    size_t total = (size_t)atol(argv[2]) * 1024 * 1024;
    size_t chunks = total / CHUNK;
    int fd[2];
    struct ring *r = NULL;
    if (use_pipe) { if (pipe(fd) == -1) { perror("pipe"); return 1; } }
    else {
        r = mmap(NULL, sizeof *r, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
        if (r == MAP_FAILED) { perror("mmap"); return 1; }
        sem_init(&r->empty, 1, SLOTS);
        sem_init(&r->full, 1, 0);
    }
    double t0 = now();
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {                                   /* ---------- consumer */
        size_t got = 0; unsigned long idx = 0; int ok = 1, out = 0;
        unsigned char buf[CHUNK];
        if (use_pipe) {
            close(fd[1]);
            for (;;) {
                size_t have = 0; ssize_t n;
                while (have < CHUNK && (n = read(fd[0], buf + have, CHUNK - have)) > 0)
                    have += (size_t)n;
                if (have == 0) break;                 /* EOF: writer closed the pipe */
                ok &= check(buf, have, idx++); got += have;
            }
            close(fd[0]);
        } else {
            for (;;) {
                sem_wait(&r->full);
                size_t len = r->len[out];
                if (len == 0) break;                  /* end-of-data marker */
                ok &= check(r->data[out], len, idx++); got += len;
                out = (out + 1) % SLOTS;
                sem_post(&r->empty);
            }
        }
        _exit(ok && got == total ? 0 : 1);
    }
    if (use_pipe) close(fd[0]);                       /* ---------- producer (parent) */
    unsigned char buf[CHUNK];
    int in = 0;
    for (size_t i = 0; i < chunks; i++) {
        if (use_pipe) {
            memset(buf, (int)(i & 0xFF), CHUNK);
            size_t sent = 0;
            while (sent < CHUNK) {
                ssize_t n = write(fd[1], buf + sent, CHUNK - sent);
                if (n < 0) { perror("write"); return 1; }
                sent += (size_t)n;
            }
        } else {
            sem_wait(&r->empty);
            memset(r->data[in], (int)(i & 0xFF), CHUNK);
            r->len[in] = CHUNK;
            in = (in + 1) % SLOTS;
            sem_post(&r->full);
        }
    }
    if (use_pipe) close(fd[1]);
    else { sem_wait(&r->empty); r->len[in] = 0; sem_post(&r->full); }
    int st; waitpid(pid, &st, 0);
    double t = now() - t0;
    printf("%s: %zu MB transferred in %.4f s (%.1f MB/s), data check %s\n", argv[1],
           total >> 20, t, (double)(total >> 20) / t,
           (WIFEXITED(st) && WEXITSTATUS(st) == 0) ? "OK" : "FAILED");
    return 0;
}
