/* q4_shm_readings.c - the same weather-station exchange through shared memory
 * protected by two POSIX semaphores (bounded ring buffer, one producer, one consumer).
 * Build: gcc -std=c11 -Wall -Wextra -pthread -o q4_shm_readings q4_shm_readings.c
 * Run  : ./q4_shm_readings                                                        */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>

#define SLOTS 4
struct shared {
    sem_t empty, full;            /* counting semaphores: free slots / filled slots */
    int value[SLOTS];
    int last[SLOTS];              /* 1 = end-of-data marker (replaces pipe EOF) */
};

int main(void)
{
    struct shared *s = mmap(NULL, sizeof *s, PROT_READ | PROT_WRITE,
                            MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (s == MAP_FAILED) { perror("mmap"); return 1; }
    sem_init(&s->empty, 1, SLOTS);   /* pshared = 1: shared between processes */
    sem_init(&s->full, 1, 0);

    pid_t pid = fork();
    if (pid == 0) {                                  /* analyser (consumer) */
        int out = 0, count = 0, sum = 0, max = 0;
        for (;;) {
            sem_wait(&s->full);
            int v = s->value[out], last = s->last[out];
            out = (out + 1) % SLOTS;
            sem_post(&s->empty);
            if (last) break;
            count++; sum += v; if (v > max) max = v;
        }
        printf("analyser: %d readings, average %.1f, max %d\n", count,
               count ? (double)sum / count : 0.0, max);
        fflush(stdout);
        _exit(0);
    }
    int readings[] = {31, 33, 36, 34, 41, 38};      /* sensor reader (producer) */
    int in = 0;
    for (int i = 0; i < 7; i++) {                    /* 6 readings + end marker */
        sem_wait(&s->empty);
        s->value[in] = i < 6 ? readings[i] : 0;
        s->last[in]  = (i == 6);
        in = (in + 1) % SLOTS;
        sem_post(&s->full);
    }
    waitpid(pid, NULL, 0);
    printf("reader: done\n");
    sem_destroy(&s->empty); sem_destroy(&s->full);
    munmap(s, sizeof *s);
    return 0;
}
