#!/bin/bash
# Run once inside the repo folder after `git init` and setting your name/email.
# Makes one commit per task so the history shows progressive work.
set -e
git add README.md Makefile environment_used_for_outputs.txt && git commit -m "Add README, Makefile and environment record"
for q in Q1 Q2 Q3 Q4 Q5 Q6; do
  git add $q && git commit -m "$q: source code, outputs and screenshots"
done
git log --oneline
