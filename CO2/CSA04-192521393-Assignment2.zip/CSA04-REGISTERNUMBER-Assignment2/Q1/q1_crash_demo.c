/* q1_crash_demo.c - failure isolation: a crashing session as a process vs a thread.
 * Build: gcc -std=c11 -Wall -Wextra -pthread -o q1_crash_demo q1_crash_demo.c
 * Run  : ./q1_crash_demo process   |   ./q1_crash_demo thread                   */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/wait.h>

static void *faulty_session(void *arg)
{
    (void)arg;
    volatile int *p = NULL;
    *p = 42;                                  /* deliberate segmentation fault */
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc < 2) { fprintf(stderr, "usage: %s process|thread\n", argv[0]); return 1; }
    printf("server started (PID %d)\n", getpid());
    fflush(stdout);
    if (strcmp(argv[1], "process") == 0) {
        pid_t pid = fork();
        if (pid == 0) { faulty_session(NULL); _exit(0); }
        int st;
        waitpid(pid, &st, 0);
        if (WIFSIGNALED(st))
            printf("session process killed by signal %d (%s)\n",
                   WTERMSIG(st), strsignal(WTERMSIG(st)));
    } else {
        pthread_t t;
        pthread_create(&t, NULL, faulty_session, NULL);
        pthread_join(t, NULL);                /* never returns: whole process dies */
    }
    printf("server still running: other sessions are unaffected\n");
    return 0;
}
