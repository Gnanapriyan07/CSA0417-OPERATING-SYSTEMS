/* q1_create_bench.c - cost of creating+destroying a process versus a thread.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q1_create_bench q1_create_bench.c
 * Run  : ./q1_create_bench fork 2000   |   ./q1_create_bench thread 2000        */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/wait.h>

static void *empty_session(void *arg) { (void)arg; return NULL; }

static double now_ms(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1000.0 + t.tv_nsec / 1e6;
}

int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s fork|thread N\n", argv[0]); return 1; }
    int n = atoi(argv[2]);
    double t0 = now_ms();
    for (int i = 0; i < n; i++) {
        if (strcmp(argv[1], "fork") == 0) {
            pid_t pid = fork();
            if (pid < 0) { perror("fork"); return 1; }
            if (pid == 0) _exit(0);
            waitpid(pid, NULL, 0);
        } else {
            pthread_t t;
            if (pthread_create(&t, NULL, empty_session, NULL) != 0) {
                fprintf(stderr, "pthread_create failed\n"); return 1;
            }
            pthread_join(t, NULL);
        }
    }
    double ms = now_ms() - t0;
    printf("%s: %d create+join cycles in %.3f ms (%.2f us per cycle)\n",
           argv[1], n, ms, ms * 1000.0 / n);
    return 0;
}
