/* q1_switch_bench.c - context-switch cost: two processes versus two threads exchanging
 * one byte through a pair of pipes (each round trip forces two context switches when
 * both run on the same CPU).  Mode "mem" creates N sleeping threads and prints VmRSS.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q1_switch_bench q1_switch_bench.c
 * Run  : ./q1_switch_bench proc 100000 | ./q1_switch_bench thread 100000
 *        ./q1_switch_bench mem 2000                                               */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <pthread.h>
#include <sys/wait.h>

static int ab[2], ba[2];                         /* parent->child and child->parent pipes */
static long rounds;

static void *echo(void *arg)                     /* the "other" side: read a byte, send it back */
{
    (void)arg; char c;
    for (long i = 0; i < rounds; i++) {
        if (read(ab[0], &c, 1) != 1) break;
        if (write(ba[1], &c, 1) != 1) break;
    }
    return NULL;
}
static void *sleeper(void *arg) { (void)arg; sleep(5); return NULL; }

int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s proc|thread|mem N\n", argv[0]); return 1; }
    rounds = atol(argv[2]);
    if (strcmp(argv[1], "mem") == 0) {
        for (long i = 0; i < rounds; i++) {
            pthread_t t; pthread_attr_t a; pthread_attr_init(&a);
            pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
            if (pthread_create(&t, &a, sleeper, NULL)) { fprintf(stderr, "create failed at %ld\n", i); break; }
        }
        sleep(1);
        FILE *f = fopen("/proc/self/status", "r"); char line[256]; long rss = 0, vm = 0;
        while (f && fgets(line, sizeof line, f)) {
            sscanf(line, "VmRSS: %ld", &rss); sscanf(line, "VmSize: %ld", &vm);
        }
        if (f) fclose(f);
        printf("%ld sleeping threads: VmRSS = %ld KB, VmSize = %ld KB\n", rounds, rss, vm);
        return 0;
    }
    if (pipe(ab) || pipe(ba)) { perror("pipe"); return 1; }
    cpu_set_t set; CPU_ZERO(&set); CPU_SET(0, &set); sched_setaffinity(0, sizeof set, &set);  /* one CPU */
    struct timespec t0, t1; pid_t pid = 0; pthread_t th;
    if (strcmp(argv[1], "proc") == 0) { pid = fork(); if (pid == 0) { echo(NULL); _exit(0); } }
    else pthread_create(&th, NULL, echo, NULL);
    clock_gettime(CLOCK_MONOTONIC, &t0);
    char c = 'x';
    for (long i = 0; i < rounds; i++) {
        if (write(ab[1], &c, 1) != 1 || read(ba[0], &c, 1) != 1) break;
    }
    clock_gettime(CLOCK_MONOTONIC, &t1);
    if (pid) waitpid(pid, NULL, 0); else pthread_join(th, NULL);
    double us = ((t1.tv_sec - t0.tv_sec) * 1e9 + (t1.tv_nsec - t0.tv_nsec)) / 1e3;
    printf("%s: %ld round trips, %.3f us per context switch (2 per round trip, includes pipe syscalls)\n",
           argv[1], rounds, us / (2.0 * rounds));
    return 0;
}
