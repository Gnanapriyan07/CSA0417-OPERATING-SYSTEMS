/* q1_fork.c - Online examination server: one child process per student session.
 * Build: gcc -std=c11 -Wall -Wextra -o q1_fork q1_fork.c
 * Run  : ./q1_fork [sessions] [wait_seconds] [busy_ms]                          */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/wait.h>

static void busy_for_ms(long ms)            /* CPU phase: process is Ready/Running */
{
    struct timespec t0, t;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    do {
        clock_gettime(CLOCK_MONOTONIC, &t);
    } while ((t.tv_sec - t0.tv_sec) * 1000L +
             (t.tv_nsec - t0.tv_nsec) / 1000000L < ms);
}

int main(int argc, char *argv[])
{
    int n    = argc > 1 ? atoi(argv[1]) : 5;     /* number of student sessions */
    int wait = argc > 2 ? atoi(argv[2]) : 30;    /* seconds spent "waiting for I/O" */
    long busy = argc > 3 ? atol(argv[3]) : 500;  /* milliseconds of CPU work */
    if (n < 1) return 1;
    pid_t *pids = calloc((size_t)n, sizeof *pids);
    if (!pids) { perror("calloc"); return 1; }

    printf("server PID %d creating %d session processes\n", getpid(), n);
    fflush(stdout);                              /* avoid duplicated buffered output */
    for (int i = 0; i < n; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); break; }
        if (pid == 0) {                          /* ---- child = one student session */
            printf("session %d: PID %d, parent %d\n", i, getpid(), getppid());
            fflush(stdout);
            busy_for_ms(busy);                   /* compute: Ready <-> Running */
            sleep((unsigned)wait);               /* blocked: Waiting state */
            _exit(i % 256);                      /* terminated; status goes to parent */
        }
        pids[i] = pid;                           /* ---- parent keeps child PID */
    }
    for (int i = 0; i < n; i++) {
        int status;
        if (pids[i] > 0 && waitpid(pids[i], &status, 0) > 0 && WIFEXITED(status))
            printf("session %d (PID %d) exited with status %d\n",
                   i, pids[i], WEXITSTATUS(status));
    }
    free(pids);
    printf("all sessions finished\n");
    return 0;
}
