/* q5_booking.c - railway booking: global lock vs train-level lock vs coach-level lock.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q5_booking q5_booking.c
 * Run  : ./q5_booking global|train|coach THREADS [BOOKINGS_PER_THREAD]            */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>

#define TRAINS 20
#define COACHES 10
#define SEATS 72
#define WORK 2000                      /* iterations standing in for payment/validation */
static unsigned char booked[TRAINS][COACHES][SEATS];
static pthread_mutex_t locks[TRAINS * COACHES];     /* indexes used depend on the mode */
static enum { GLOBAL, TRAIN, COACH } mode;
static int per_thread = 4000;
static long successes[256];

static pthread_mutex_t *lock_for(int t, int c)
{
    return &locks[mode == GLOBAL ? 0 : mode == TRAIN ? t : t * COACHES + c];
}
static void *agent(void *arg)
{
    long id = (long)arg;
    unsigned seed = (unsigned)id * 7919u + 1;
    for (int n = 0; n < per_thread; n++) {
        int t = rand_r(&seed) % TRAINS, c = rand_r(&seed) % COACHES;
        int start = rand_r(&seed) % SEATS;
        pthread_mutex_t *m = lock_for(t, c);
        pthread_mutex_lock(m);
        for (int k = 0; k < SEATS; k++) {                 /* find a free seat */
            int s = (start + k) % SEATS;
            if (!booked[t][c][s]) {
                volatile unsigned x = 0;
                for (int w = 0; w < WORK; w++) x += (unsigned)w;   /* payment work */
                booked[t][c][s] = 1;
                successes[id]++;
                break;
            }
        }
        pthread_mutex_unlock(m);
    }
    return NULL;
}
int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s global|train|coach THREADS [N]\n", argv[0]); return 1; }
    mode = strcmp(argv[1], "global") == 0 ? GLOBAL : strcmp(argv[1], "train") == 0 ? TRAIN : COACH;
    int nt = atoi(argv[2]);
    if (argc > 3) per_thread = atoi(argv[3]);
    if (nt < 1 || nt > 256) return 1;
    for (int i = 0; i < TRAINS * COACHES; i++) pthread_mutex_init(&locks[i], NULL);
    pthread_t th[256];
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    for (long i = 0; i < nt; i++) pthread_create(&th[i], NULL, agent, (void *)i);
    for (int i = 0; i < nt; i++) pthread_join(th[i], NULL);
    clock_gettime(CLOCK_MONOTONIC, &t1);
    long sold = 0, flagged = 0;
    for (int i = 0; i < nt; i++) sold += successes[i];
    for (int t = 0; t < TRAINS; t++) for (int c = 0; c < COACHES; c++)
        for (int s = 0; s < SEATS; s++) flagged += booked[t][c][s];
    double sec = (double)(t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
    printf("lock=%s threads=%d: %ld bookings in %.3f s = %.0f bookings/s; sold=%ld flagged=%ld %s\n",
           argv[1], nt, sold, sec, sold / sec, sold, flagged, sold == flagged ? "(no double sale)" : "(DOUBLE SALE!)");
    return 0;
}
