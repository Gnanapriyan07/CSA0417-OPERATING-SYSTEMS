/* q5_prodcons_multi.c - bounded buffer with P producers and C consumers.
 * Every item is a unique value (producer*100 + k); the program checks that each one
 * is consumed exactly once. The optional argument "nomutex" removes the buffer mutex.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q5_multi q5_prodcons_multi.c
 * Run  : ./q5_multi 1 1 | ./q5_multi 4 4 | ./q5_multi 4 4 nomutex                */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>
#include <pthread.h>
#include <semaphore.h>

#define SIZE 5
#define ITEMS 20                       /* items produced by each producer */
#define MAXP 16
static int buffer[SIZE], in = 0, out = 0;
static sem_t empty, full;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static atomic_int seen[MAXP * 100 + 100];   /* how many times each value was consumed */
static atomic_long consumed_sum = 0;
static int use_mutex = 1, nprod, ncons;

static void *producer(void *arg)
{
    int id = (int)(long)arg;
    for (int k = 1; k <= ITEMS; k++) {
        sem_wait(&empty);
        if (use_mutex) pthread_mutex_lock(&lock);
        buffer[in] = id * 100 + k;
        in = (in + 1) % SIZE;
        if (use_mutex) pthread_mutex_unlock(&lock);
        sem_post(&full);
    }
    return NULL;
}

static void *consumer(void *arg)
{
    (void)arg;
    int share = nprod * ITEMS / ncons;           /* items this consumer must take */
    for (int k = 0; k < share; k++) {
        sem_wait(&full);
        if (use_mutex) pthread_mutex_lock(&lock);
        int item = buffer[out];
        out = (out + 1) % SIZE;
        if (use_mutex) pthread_mutex_unlock(&lock);
        sem_post(&empty);
        atomic_fetch_add(&seen[item], 1);        /* atomic: bookkeeping must not race */
        atomic_fetch_add(&consumed_sum, item);
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s P C [nomutex]\n", argv[0]); return 1; }
    nprod = atoi(argv[1]); ncons = atoi(argv[2]);
    if (argc > 3 && strcmp(argv[3], "nomutex") == 0) use_mutex = 0;
    if (nprod < 1 || nprod > MAXP || ncons < 1 || (nprod * ITEMS) % ncons != 0) {
        fprintf(stderr, "need 1<=P<=%d and P*%d divisible by C\n", MAXP, ITEMS); return 1;
    }
    sem_init(&empty, 0, SIZE);
    sem_init(&full, 0, 0);
    pthread_t p[MAXP], c[MAXP * ITEMS];
    for (long i = 0; i < ncons; i++) pthread_create(&c[i], NULL, consumer, NULL);
    for (long i = 0; i < nprod; i++) pthread_create(&p[i], NULL, producer, (void *)(i + 1));
    for (int i = 0; i < nprod; i++) pthread_join(p[i], NULL);
    for (int i = 0; i < ncons; i++) pthread_join(c[i], NULL);

    long expected = 0; int missing = 0, duplicates = 0;
    for (int id = 1; id <= nprod; id++)
        for (int k = 1; k <= ITEMS; k++) {
            expected += id * 100 + k;
            int s = atomic_load(&seen[id * 100 + k]);
            if (s == 0) missing++; else if (s > 1) duplicates += s - 1;
        }
    printf("P=%d C=%d mutex=%s: consumed sum = %ld (expected %ld), missing %d, duplicates %d -> %s\n",
           nprod, ncons, use_mutex ? "on" : "off", (long)atomic_load(&consumed_sum), expected,
           missing, duplicates, (missing == 0 && duplicates == 0) ? "PASS" : "FAIL");
    sem_destroy(&empty); sem_destroy(&full);
    return (missing == 0 && duplicates == 0) ? 0 : 1;
}
