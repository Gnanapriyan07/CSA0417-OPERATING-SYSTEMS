/* q5_counter.c - shared counter: atomic add vs spin lock vs mutex.
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q5_counter q5_counter.c
 * Run  : ./q5_counter atomic|spin|mutex THREADS [UPDATES_PER_THREAD] [CS_WORK]    */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdatomic.h>
#include <pthread.h>

static atomic_long a_counter = 0;
static long counter = 0;
static atomic_flag spin = ATOMIC_FLAG_INIT;
static pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
static long updates = 1000000, cs_work = 0;
static const char *mode;

static void *worker(void *arg)
{
    (void)arg;
    for (long i = 0; i < updates; i++) {
        if (strcmp(mode, "atomic") == 0) atomic_fetch_add(&a_counter, 1);
        else if (strcmp(mode, "spin") == 0) {
            while (atomic_flag_test_and_set_explicit(&spin, memory_order_acquire)) { }
            counter++;
            for (volatile long w = 0; w < cs_work; w++) { }
            atomic_flag_clear_explicit(&spin, memory_order_release);
        } else {
            pthread_mutex_lock(&mtx);
            counter++;
            for (volatile long w = 0; w < cs_work; w++) { }
            pthread_mutex_unlock(&mtx);
        }
    }
    return NULL;
}
int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s atomic|spin|mutex THREADS [UPDATES] [CS_WORK]\n", argv[0]); return 1; }
    mode = argv[1];
    int n = atoi(argv[2]);
    if (argc > 3) updates = atol(argv[3]);
    if (argc > 4) cs_work = atol(argv[4]);
    pthread_t *t = malloc((size_t)n * sizeof *t);
    struct timespec w0, w1;
    clock_t c0 = clock();                                   /* CPU time of all threads */
    clock_gettime(CLOCK_MONOTONIC, &w0);
    for (int i = 0; i < n; i++) pthread_create(&t[i], NULL, worker, NULL);
    for (int i = 0; i < n; i++) pthread_join(t[i], NULL);
    clock_gettime(CLOCK_MONOTONIC, &w1);
    double cpu = (double)(clock() - c0) / CLOCKS_PER_SEC;
    double wall = (double)(w1.tv_sec - w0.tv_sec) + (w1.tv_nsec - w0.tv_nsec) / 1e9;
    long got = strcmp(mode, "atomic") == 0 ? atomic_load(&a_counter) : counter;
    printf("%s threads=%d: counter=%ld (expected %ld) wall=%.3f s cpu=%.3f s ns/update=%.1f\n",
           mode, n, got, (long)n * updates, wall, cpu, wall * 1e9 / ((double)n * updates));
    free(t);
    return 0;
}
