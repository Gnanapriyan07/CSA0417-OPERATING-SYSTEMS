/* q5_monitor.c - bounded buffer written as a monitor (mutex + condition variables).
 * Build: gcc -std=c11 -O2 -Wall -Wextra -pthread -o q5_monitor q5_monitor.c
 * Run  : ./q5_monitor 4 4                                                         */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define SIZE 5
#define ITEMS 20
struct monitor {                         /* data + lock + conditions kept together */
    int buf[SIZE], in, out, count;
    pthread_mutex_t m;
    pthread_cond_t not_full, not_empty;
} mon = { {0}, 0, 0, 0, PTHREAD_MUTEX_INITIALIZER,
          PTHREAD_COND_INITIALIZER, PTHREAD_COND_INITIALIZER };
static long total = 0;
static pthread_mutex_t total_lock = PTHREAD_MUTEX_INITIALIZER;
static int nprod, ncons;

static void put(int item)                /* monitor procedure */
{
    pthread_mutex_lock(&mon.m);
    while (mon.count == SIZE) pthread_cond_wait(&mon.not_full, &mon.m);   /* re-check */
    mon.buf[mon.in] = item; mon.in = (mon.in + 1) % SIZE; mon.count++;
    pthread_cond_signal(&mon.not_empty);
    pthread_mutex_unlock(&mon.m);
}
static int get(void)                     /* monitor procedure */
{
    pthread_mutex_lock(&mon.m);
    while (mon.count == 0) pthread_cond_wait(&mon.not_empty, &mon.m);
    int item = mon.buf[mon.out]; mon.out = (mon.out + 1) % SIZE; mon.count--;
    pthread_cond_signal(&mon.not_full);
    pthread_mutex_unlock(&mon.m);
    return item;
}
static void *producer(void *a) { (void)a; for (int k = 1; k <= ITEMS; k++) put(k); return NULL; }
static void *consumer(void *a)
{
    (void)a;
    for (int k = 0; k < nprod * ITEMS / ncons; k++) {
        int item = get();
        pthread_mutex_lock(&total_lock); total += item; pthread_mutex_unlock(&total_lock);
    }
    return NULL;
}
int main(int argc, char *argv[])
{
    nprod = argc > 1 ? atoi(argv[1]) : 1; ncons = argc > 2 ? atoi(argv[2]) : 1;
    if (nprod < 1 || nprod > 16 || ncons < 1 || (nprod * ITEMS) % ncons) return 1;
    pthread_t p[16], c[320];
    for (int i = 0; i < ncons; i++) pthread_create(&c[i], NULL, consumer, NULL);
    for (int i = 0; i < nprod; i++) pthread_create(&p[i], NULL, producer, NULL);
    for (int i = 0; i < nprod; i++) pthread_join(p[i], NULL);
    for (int i = 0; i < ncons; i++) pthread_join(c[i], NULL);
    printf("monitor: P=%d C=%d, sum = %ld (expected %d)\n", nprod, ncons, total,
           nprod * ITEMS * (ITEMS + 1) / 2);
    return 0;
}
