#!/bin/bash
# Runs ./q5_prodcons 100 times and counts correct results.
pass=0
for i in $(seq 1 100); do
    ./q5_prodcons | grep -q "sum = 210 (expected 210)" && pass=$((pass+1))
done
echo "correct runs: $pass / 100"
